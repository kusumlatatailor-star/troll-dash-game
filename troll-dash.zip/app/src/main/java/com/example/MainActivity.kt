package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.game.GameScreen
import com.example.ui.screens.GrandVictoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LevelSelectScreen
import com.example.ui.theme.TrollDashTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.TrollDashViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            TrollDashTheme {
                TrollDashApp()
            }
        }
    }
}

@Composable
fun TrollDashApp(
    viewModel: TrollDashViewModel = viewModel()
) {
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    when (val screen = uiState.screen) {
        AppScreen.Home -> HomeScreen(
            progress = progress,
            onPlayCurrentLevel = { viewModel.startLevel(progress.unlockedLevel) },
            onOpenLevels = { viewModel.openLevelSelect() },
            onToggleSound = { viewModel.toggleSound() },
            onToggleHaptics = { viewModel.toggleHaptics() }
        )

        AppScreen.LevelSelect -> LevelSelectScreen(
            progress = progress,
            onSelectLevel = { lvl -> viewModel.startLevel(lvl) },
            onUnlockAll = { viewModel.unlockAllLevels() },
            onBack = { viewModel.openHome() }
        )

        is AppScreen.Playing -> GameScreen(
            levelNumber = screen.levelNumber,
            levelDeaths = uiState.levelDeaths,
            deathGeneration = uiState.deathGeneration,
            soundEnabled = progress.soundEnabled,
            hapticsEnabled = progress.hapticsEnabled,
            onGameEvent = { viewModel.onGameEvent(it) },
            onButtonDodged = { viewModel.onRespawnButtonDodged() },
            onToggleSound = { viewModel.toggleSound() },
            onNextLevel = { viewModel.startNextLevel() },
            onBack = { viewModel.openLevelSelect() }
        )

        AppScreen.GrandVictory -> GrandVictoryScreen(
            totalDeaths = progress.totalDeaths,
            onReplayAll = { viewModel.startLevel(1) },
            onBackToMenu = { viewModel.openHome() }
        )
    }
}
