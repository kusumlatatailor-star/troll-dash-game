package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * Lightweight procedural retro 8-bit chiptune sound synthesizer using AudioTrack.
 * Zero external audio assets needed; fails safely if audio output is unavailable.
 */
class TrollSoundEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile
    var enabled: Boolean = true

    fun playJump() = playToneSweep(startHz = 290f, endHz = 620f, durationMs = 75, volume = 0.24f, square = true)

    fun playDeathSplat() {
        if (!enabled) return
        scope.launch {
            playNoiseBurst(durationMs = 150, volume = 0.30f)
            playToneSweepSync(startHz = 320f, endHz = 95f, durationMs = 170, volume = 0.28f, square = true)
        }
    }

    fun playTrapTrigger() = playToneSweep(startHz = 780f, endHz = 420f, durationMs = 65, volume = 0.22f, square = true)

    fun playButtonDodge() {
        if (!enabled) return
        scope.launch {
            playToneSweepSync(startHz = 420f, endHz = 920f, durationMs = 70, volume = 0.25f, square = false)
            playToneSweepSync(startHz = 880f, endHz = 560f, durationMs = 65, volume = 0.22f, square = false)
        }
    }

    fun playTrollLaugh() {
        if (!enabled) return
        scope.launch {
            val notes = listOf(660f, 520f, 660f, 520f, 780f)
            for (hz in notes) {
                playToneSweepSync(startHz = hz, endHz = hz * 0.94f, durationMs = 55, volume = 0.22f, square = true)
            }
        }
    }

    fun playLevelClear() {
        if (!enabled) return
        scope.launch {
            val notes = listOf(523f, 659f, 784f, 1046f)
            for (hz in notes) {
                playToneSweepSync(startHz = hz, endHz = hz, durationMs = 85, volume = 0.24f, square = true)
            }
        }
    }

    private fun playToneSweep(
        startHz: Float,
        endHz: Float,
        durationMs: Int,
        volume: Float,
        square: Boolean
    ) {
        if (!enabled) return
        scope.launch {
            playToneSweepSync(startHz, endHz, durationMs, volume, square)
        }
    }

    private fun playToneSweepSync(
        startHz: Float,
        endHz: Float,
        durationMs: Int,
        volume: Float,
        square: Boolean
    ) {
        val sampleRate = 22050
        val count = (sampleRate * durationMs / 1000).coerceAtLeast(1)
        val samples = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val t = i.toFloat() / count
            val freq = startHz + (endHz - startHz) * t
            phase += 2.0 * PI * freq / sampleRate
            val env = (1f - t).coerceIn(0f, 1f)
            val raw = sin(phase)
            val wave = if (square) (if (raw >= 0.0) 1.0 else -1.0) else raw
            samples[i] = (wave * env * volume * Short.MAX_VALUE).toInt().toShort()
        }
        writePcm(samples, sampleRate)
    }

    private fun playNoiseBurst(durationMs: Int, volume: Float) {
        val sampleRate = 22050
        val count = (sampleRate * durationMs / 1000).coerceAtLeast(1)
        val samples = ShortArray(count)
        for (i in 0 until count) {
            val env = 1f - (i.toFloat() / count)
            val noise = Random.nextFloat() * 2f - 1f
            samples[i] = (noise * env * volume * Short.MAX_VALUE).toInt().toShort()
        }
        writePcm(samples, sampleRate)
    }

    private fun writePcm(samples: ShortArray, sampleRate: Int) {
        runCatching {
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufBytes = (samples.size * 2).coerceAtLeast(minBuf)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufBytes)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(samples, 0, samples.size)
            track.play()
            val sleepMs = (samples.size * 1000L / sampleRate) + 25L
            Thread.sleep(sleepMs)
            track.stop()
            track.release()
        }
    }
}
