package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.trollDashDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "troll_dash_prefs"
)

data class PlayerProgress(
    val unlockedLevel: Int = 1,
    val totalDeaths: Int = 0,
    val completedLevels: Set<Int> = emptySet(),
    val bestDeathsByLevel: Map<Int, Int> = emptyMap(),
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true
)

class GameProgressRepository(private val context: Context) {

    private object Keys {
        val UNLOCKED_LEVEL = intPreferencesKey("unlocked_level")
        val TOTAL_DEATHS = intPreferencesKey("total_deaths")
        val COMPLETED_LEVELS = stringPreferencesKey("completed_levels")
        val BEST_DEATHS = stringPreferencesKey("best_deaths")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
    }

    val progressFlow: Flow<PlayerProgress> = context.trollDashDataStore.data.map { prefs ->
        val completed = prefs[Keys.COMPLETED_LEVELS]
            ?.split(",")
            ?.mapNotNull { it.toIntOrNull() }
            ?.toSet()
            ?: emptySet()
        val bestMap = prefs[Keys.BEST_DEATHS]
            ?.split(",")
            ?.mapNotNull { entry ->
                val parts = entry.split(":")
                if (parts.size == 2) {
                    val lvl = parts[0].toIntOrNull()
                    val best = parts[1].toIntOrNull()
                    if (lvl != null && best != null) lvl to best else null
                } else null
            }
            ?.toMap()
            ?: emptyMap()
        PlayerProgress(
            unlockedLevel = (prefs[Keys.UNLOCKED_LEVEL] ?: 1).coerceIn(1, 10),
            totalDeaths = prefs[Keys.TOTAL_DEATHS] ?: 0,
            completedLevels = completed,
            bestDeathsByLevel = bestMap,
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true
        )
    }

    suspend fun recordDeath() {
        context.trollDashDataStore.edit { prefs ->
            prefs[Keys.TOTAL_DEATHS] = (prefs[Keys.TOTAL_DEATHS] ?: 0) + 1
        }
    }

    suspend fun recordLevelCleared(levelNumber: Int, deathsInRun: Int) {
        context.trollDashDataStore.edit { prefs ->
            val currentUnlocked = prefs[Keys.UNLOCKED_LEVEL] ?: 1
            val nextUnlock = (levelNumber + 1).coerceAtMost(10)
            if (nextUnlock > currentUnlocked) {
                prefs[Keys.UNLOCKED_LEVEL] = nextUnlock
            }
            val completed = prefs[Keys.COMPLETED_LEVELS]
                ?.split(",")
                ?.mapNotNull { it.toIntOrNull() }
                ?.toMutableSet()
                ?: mutableSetOf()
            completed.add(levelNumber)
            prefs[Keys.COMPLETED_LEVELS] = completed.sorted().joinToString(",")

            val bestMap = prefs[Keys.BEST_DEATHS]
                ?.split(",")
                ?.mapNotNull { entry ->
                    val parts = entry.split(":")
                    if (parts.size == 2) {
                        val lvl = parts[0].toIntOrNull()
                        val best = parts[1].toIntOrNull()
                        if (lvl != null && best != null) lvl to best else null
                    } else null
                }
                ?.toMap()
                ?.toMutableMap()
                ?: mutableMapOf()

            val prevBest = bestMap[levelNumber]
            if (prevBest == null || deathsInRun < prevBest) {
                bestMap[levelNumber] = deathsInRun
            }
            prefs[Keys.BEST_DEATHS] = bestMap.entries
                .sortedBy { it.key }
                .joinToString(",") { "${it.key}:${it.value}" }
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.trollDashDataStore.edit { it[Keys.SOUND_ENABLED] = enabled }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        context.trollDashDataStore.edit { it[Keys.HAPTICS_ENABLED] = enabled }
    }

    suspend fun unlockAllLevels() {
        context.trollDashDataStore.edit { it[Keys.UNLOCKED_LEVEL] = 10 }
    }

    suspend fun resetProgress() {
        context.trollDashDataStore.edit { prefs ->
            prefs[Keys.UNLOCKED_LEVEL] = 1
            prefs[Keys.TOTAL_DEATHS] = 0
            prefs[Keys.COMPLETED_LEVELS] = ""
            prefs[Keys.BEST_DEATHS] = ""
        }
    }
}
