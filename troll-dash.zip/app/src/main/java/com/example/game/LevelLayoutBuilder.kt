package com.example.game

/**
 * Declarative level layout builder supporting safe stone platforms alongside
 * disguised deceptive platforms that appear identical to safe blocks until
 * touched—vanishing out from under the player or rotating open like a trapdoor.
 */
@DslMarker
annotation class LevelLayoutDsl

@LevelLayoutDsl
class LevelLayoutBuilder(
    private val number: Int,
    private val title: String,
    private val subtitle: String,
    private val difficultySkulls: Int,
    private val worldWidth: Float,
    private val spawnX: Float,
    private val spawnY: Float,
    private val accentColorHex: Long = 0xFFFF7A1A
) {
    private val platforms = mutableListOf<PlatformDef>()
    private val spikes = mutableListOf<SpikeDef>()
    private val projectiles = mutableListOf<ProjectileTrapDef>()
    private val fakeCheckpoints = mutableListOf<FakeCheckpointDef>()
    private val flipZones = mutableListOf<ControlFlipZoneDef>()
    private var chasingSaw: ChasingSawDef? = null
    private var exitDoor: ExitDoorDef = ExitDoorDef(x = worldWidth - 64f, y = 180f)
    private var deathMessages: List<String> = emptyList()
    private var autoId = 0

    private fun nextId(prefix: String): String = "l${number}_${prefix}_${++autoId}"

    /** Standard safe stone platform. */
    fun solid(
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        hiddenUntilFakeWin: Boolean = false
    ) {
        platforms += PlatformDef(
            id = nextId("solid"),
            x = x,
            y = y,
            w = w,
            h = h,
            kind = PlatformKind.SOLID,
            hiddenUntilFakeWin = hiddenUntilFakeWin
        )
    }

    /**
     * Disguised safe platform that looks 100% identical to solid stone,
     * then flashes briefly and VANISHES the instant the player touches it!
     */
    fun vanishOnTouch(
        x: Float,
        y: Float,
        w: Float,
        h: Float = 24f,
        vanishDelaySec: Float = 0.085f,
        taunt: String? = "POOF! GAYAB! 💨"
    ) {
        platforms += PlatformDef(
            id = nextId("vanish"),
            x = x,
            y = y,
            w = w,
            h = h,
            kind = PlatformKind.VANISH_ON_TOUCH,
            triggerOnStep = true,
            vanishDelaySec = vanishDelaySec,
            tauntOnTrigger = taunt
        )
    }

    /**
     * Disguised safe platform that looks 100% identical to solid stone,
     * then ROTATES open like a mechanical trapdoor the instant the player steps on it!
     */
    fun rotateOnTouch(
        x: Float,
        y: Float,
        w: Float,
        h: Float = 22f,
        targetDeg: Float = 92f,
        speedDegPerSec: Float = 520f,
        pivot: RotationPivot = RotationPivot.LEFT_EDGE,
        taunt: String? = "DARWAZA KHUL GAYA! 🌀"
    ) {
        platforms += PlatformDef(
            id = nextId("rotate"),
            x = x,
            y = y,
            w = w,
            h = h,
            kind = PlatformKind.ROTATE_ON_TOUCH,
            triggerOnStep = true,
            rotateTargetDeg = targetDeg,
            rotateSpeedDeg = speedDegPerSec,
            rotatePivot = pivot,
            tauntOnTrigger = taunt
        )
    }

    /** Looks solid until player enters X trigger range, then drops straight down. */
    fun dropTrap(
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        triggerMinX: Float,
        triggerMaxX: Float,
        delaySec: Float = 0.05f,
        taunt: String? = null
    ) {
        platforms += PlatformDef(
            id = nextId("drop"),
            x = x,
            y = y,
            w = w,
            h = h,
            kind = PlatformKind.DROP_TRAP,
            triggerMinX = triggerMinX,
            triggerMaxX = triggerMaxX,
            delaySec = delaySec,
            tauntOnTrigger = taunt
        )
    }

    /** Visibly cracked platform that crumbles quickly once stepped on. */
    fun crumble(
        x: Float,
        y: Float,
        w: Float,
        h: Float = 22f,
        crumbleSec: Float = 0.16f,
        taunt: String? = null
    ) {
        platforms += PlatformDef(
            id = nextId("crumble"),
            x = x,
            y = y,
            w = w,
            h = h,
            kind = PlatformKind.CRUMBLE,
            crumbleSec = crumbleSec,
            tauntOnTrigger = taunt
        )
    }

    /** Invisible ceiling troll block that reveals itself when bonked from underneath. */
    fun invisibleBonk(
        x: Float,
        y: Float,
        w: Float = 34f,
        h: Float = 24f,
        taunt: String = "BONK! SIR PHUTA! 🤕"
    ) {
        platforms += PlatformDef(
            id = nextId("bonk"),
            x = x,
            y = y,
            w = w,
            h = h,
            kind = PlatformKind.INVISIBLE_BONK,
            tauntOnTrigger = taunt
        )
    }

    /** Ghost bridge that lets the player fall right through on contact. */
    fun fakeSolid(
        x: Float,
        y: Float,
        w: Float,
        h: Float = 22f,
        taunt: String = "HAVA THI WOH! 👻"
    ) {
        platforms += PlatformDef(
            id = nextId("fake"),
            x = x,
            y = y,
            w = w,
            h = h,
            kind = PlatformKind.FAKE_SOLID,
            tauntOnTrigger = taunt
        )
    }

    /** High-velocity troll bounce spring pad. */
    fun bouncePad(
        x: Float,
        y: Float,
        w: Float = 52f,
        h: Float = 20f,
        taunt: String? = "BOING! CHHAT SE BACHO!"
    ) {
        platforms += PlatformDef(
            id = nextId("bounce"),
            x = x,
            y = y,
            w = w,
            h = h,
            kind = PlatformKind.BOUNCE_TROLL,
            tauntOnTrigger = taunt
        )
    }

    fun spike(
        x: Float,
        y: Float,
        w: Float,
        h: Float = 20f,
        orientation: SpikeOrientation = SpikeOrientation.UP
    ) {
        spikes += SpikeDef(
            id = nextId("sp"),
            x = x,
            y = y,
            w = w,
            h = h,
            orientation = orientation
        )
    }

    fun popupSpike(
        x: Float,
        y: Float,
        w: Float,
        h: Float = 20f,
        triggerMinX: Float,
        triggerMaxX: Float,
        taunt: String? = null
    ) {
        spikes += SpikeDef(
            id = nextId("pop"),
            x = x,
            y = y,
            w = w,
            h = h,
            orientation = SpikeOrientation.UP,
            hiddenUntilTrigger = true,
            triggerMinX = triggerMinX,
            triggerMaxX = triggerMaxX,
            tauntOnTrigger = taunt
        )
    }

    fun fallingSpike(
        x: Float,
        y: Float,
        w: Float,
        h: Float = 24f,
        triggerMinX: Float,
        triggerMaxX: Float,
        fallSpeed: Float = 550f,
        taunt: String? = null
    ) {
        spikes += SpikeDef(
            id = nextId("fall"),
            x = x,
            y = y,
            w = w,
            h = h,
            orientation = SpikeOrientation.DOWN,
            falling = true,
            triggerMinX = triggerMinX,
            triggerMaxX = triggerMaxX,
            fallSpeed = fallSpeed,
            tauntOnTrigger = taunt
        )
    }

    fun slidingSpike(
        x: Float,
        y: Float,
        w: Float,
        h: Float = 20f,
        triggerMinX: Float,
        triggerMaxX: Float,
        slideTargetX: Float,
        slideSpeed: Float = 300f,
        taunt: String? = null
    ) {
        spikes += SpikeDef(
            id = nextId("slide"),
            x = x,
            y = y,
            w = w,
            h = h,
            orientation = SpikeOrientation.UP,
            triggerMinX = triggerMinX,
            triggerMaxX = triggerMaxX,
            slideTargetX = slideTargetX,
            slideSpeed = slideSpeed,
            tauntOnTrigger = taunt
        )
    }

    fun sniper(
        startX: Float,
        startY: Float,
        vx: Float,
        triggerMinX: Float,
        taunt: String? = null
    ) {
        projectiles += ProjectileTrapDef(
            id = nextId("proj"),
            startX = startX,
            startY = startY,
            vx = vx,
            triggerMinX = triggerMinX,
            taunt = taunt
        )
    }

    fun fakeCheckpoint(x: Float, y: Float, taunt: String = "HAHA NAKLI CHECKPOINT! 💥") {
        fakeCheckpoints += FakeCheckpointDef(id = nextId("fc"), x = x, y = y, taunt = taunt)
    }

    fun flipZone(minX: Float, maxX: Float, taunt: String = "LEFT ↔ RIGHT ULTA! 🤪") {
        flipZones += ControlFlipZoneDef(minX = minX, maxX = maxX, taunt = taunt)
    }

    fun chasingSaw(startX: Float, speed: Float, wakeDelaySec: Float = 0.25f, taunt: String = "BHAAG! AARI AA RAHI HAI! ⚙️") {
        chasingSaw = ChasingSawDef(startX = startX, speed = speed, wakeDelaySec = wakeDelaySec, taunt = taunt)
    }

    fun exitDoor(
        x: Float,
        y: Float,
        runawayTriggerDist: Float? = null,
        runawayTargetX: Float = x,
        runawayTargetY: Float = y,
        runawayTaunt: String = "BHAAG DOOR BHAAG! 🏃",
        fakeVictoryTargetX: Float? = null,
        fakeVictoryTargetY: Float? = null,
        fakeVictoryTaunt: String = "SIKE! ASLI DOOR UPAR HAI! 😈"
    ) {
        exitDoor = ExitDoorDef(
            x = x,
            y = y,
            runawayTriggerDist = runawayTriggerDist,
            runawayTargetX = runawayTargetX,
            runawayTargetY = runawayTargetY,
            runawayTaunt = runawayTaunt,
            fakeVictoryTargetX = fakeVictoryTargetX,
            fakeVictoryTargetY = fakeVictoryTargetY,
            fakeVictoryTaunt = fakeVictoryTaunt
        )
    }

    fun deathMessages(vararg messages: String) {
        deathMessages = messages.toList()
    }

    fun build(): LevelDefinition = LevelDefinition(
        number = number,
        title = title,
        subtitle = subtitle,
        difficultySkulls = difficultySkulls,
        worldWidth = worldWidth,
        spawnX = spawnX,
        spawnY = spawnY,
        platforms = platforms.toList(),
        spikes = spikes.toList(),
        projectiles = projectiles.toList(),
        fakeCheckpoints = fakeCheckpoints.toList(),
        controlFlipZones = flipZones.toList(),
        chasingSaw = chasingSaw,
        exitDoor = exitDoor,
        accentColorHex = accentColorHex,
        deathMessages = deathMessages.ifEmpty { listOf("Nipat gaye! 💀") }
    )
}

fun levelLayout(
    number: Int,
    title: String,
    subtitle: String,
    difficultySkulls: Int,
    worldWidth: Float,
    spawnX: Float,
    spawnY: Float,
    accentColorHex: Long = 0xFFFF7A1A,
    block: LevelLayoutBuilder.() -> Unit
): LevelDefinition = LevelLayoutBuilder(
    number = number,
    title = title,
    subtitle = subtitle,
    difficultySkulls = difficultySkulls,
    worldWidth = worldWidth,
    spawnX = spawnX,
    spawnY = spawnY,
    accentColorHex = accentColorHex
).apply(block).build()
