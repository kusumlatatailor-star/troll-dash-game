package com.example.game

import androidx.compose.ui.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/**
 * Pure Kotlin fixed-timestep 2D parkour & trap physics engine.
 * Designed for razor-sharp inputs, minimal reaction buffers, and comedic troll triggers.
 */
class GameEngine(
    initialLevel: LevelDefinition,
    private val onEvent: (GameEvent) -> Unit
) {

    companion object {
        const val VIEWPORT_WIDTH = 640f
        const val VIEWPORT_HEIGHT = 360f
        private const val MOVE_SPEED = 248f
        private const val GROUND_ACCEL = 2600f
        private const val AIR_ACCEL = 1950f
        private const val GRAVITY = 1520f
        private const val MAX_FALL_SPEED = 660f
        private const val JUMP_VELOCITY = -548f
        private const val BOUNCE_VELOCITY = -700f
        private const val COYOTE_TIME = 0.055f
        private const val JUMP_BUFFER_TIME = 0.085f
    }

    var snapshot: GameSnapshot = createInitialSnapshot(initialLevel)
        private set

    private var moveLeftInput = false
    private var moveRightInput = false
    private var jumpHeldInput = false
    private var jumpJustPressed = false

    fun loadLevel(level: LevelDefinition) {
        moveLeftInput = false
        moveRightInput = false
        jumpHeldInput = false
        jumpJustPressed = false
        snapshot = createInitialSnapshot(level)
    }

    fun resetCurrentLevel() {
        loadLevel(snapshot.level)
    }

    fun setMoveLeft(pressed: Boolean) {
        moveLeftInput = pressed
    }

    fun setMoveRight(pressed: Boolean) {
        moveRightInput = pressed
    }

    fun setJump(pressed: Boolean) {
        if (pressed && !jumpHeldInput) {
            jumpJustPressed = true
        }
        jumpHeldInput = pressed
    }

    private fun createInitialSnapshot(level: LevelDefinition): GameSnapshot {
        val runtimePlatforms = level.platforms.map { def ->
            RuntimePlatform(
                def = def,
                x = def.x,
                y = def.y,
                active = !def.hiddenUntilFakeWin,
                revealed = def.kind != PlatformKind.INVISIBLE_BONK && !def.hiddenUntilFakeWin
            )
        }
        val runtimeSpikes = level.spikes.map { def ->
            RuntimeSpike(def = def, x = def.x, y = def.y)
        }
        val runtimeProjectiles = level.projectiles.map { def ->
            RuntimeProjectile(def = def, x = def.startX, y = def.startY)
        }
        val runtimeCheckpoints = level.fakeCheckpoints.map { RuntimeFakeCheckpoint(it) }
        val door = RuntimeExitDoor(
            x = level.exitDoor.x,
            y = level.exitDoor.y,
            w = level.exitDoor.w,
            h = level.exitDoor.h
        )
        return GameSnapshot(
            level = level,
            phase = GamePhase.PLAYING,
            player = PlayerState(x = level.spawnX, y = level.spawnY),
            platforms = runtimePlatforms,
            spikes = runtimeSpikes,
            projectiles = runtimeProjectiles,
            fakeCheckpoints = runtimeCheckpoints,
            exitDoor = door,
            sawX = level.chasingSaw?.startX
        )
    }

    fun step(rawDt: Float): GameSnapshot {
        val dt = rawDt.coerceIn(0.001f, 0.033f)
        var s = snapshot

        // Always tick particles, screen shake, and toasts even when dead/cleared
        val nextParticles = s.particles.mapNotNull { p ->
            val nl = p.life - dt
            if (nl <= 0f) null
            else p.copy(
                x = p.x + p.vx * dt,
                y = p.y + p.vy * dt,
                vy = p.vy + 900f * dt,
                life = nl
            )
        }
        val nextShake = (s.screenShake - dt * 28f).coerceAtLeast(0f)
        val nextToast = s.activeToast?.let { t ->
            val rem = t.remainingSec - dt
            if (rem > 0f) t.copy(remainingSec = rem) else null
        }

        s = s.copy(
            particles = nextParticles,
            screenShake = nextShake,
            activeToast = nextToast
        )

        // Handle Fake Victory SIKE beat!
        if (s.phase == GamePhase.FAKE_VICTORY_SIKE) {
            val rem = s.fakeVictoryTimer - dt
            if (rem <= 0f) {
                // Reveal hidden upper climb blocks and teleport real exit door upward!
                val levelDoor = s.level.exitDoor
                val updatedPlatforms = s.platforms.map { rp ->
                    if (rp.def.hiddenUntilFakeWin) {
                        rp.copy(active = true, revealed = true)
                    } else rp
                }
                val newDoor = s.exitDoor.copy(
                    x = levelDoor.fakeVictoryTargetX ?: s.exitDoor.x,
                    y = levelDoor.fakeVictoryTargetY ?: s.exitDoor.y,
                    fakeVictoryTriggered = true
                )
                onEvent(GameEvent.TROLL_LAUGH)
                s = s.copy(
                    phase = GamePhase.PLAYING,
                    platforms = updatedPlatforms,
                    exitDoor = newDoor,
                    screenShake = 10f,
                    activeToast = TrollToast(levelDoor.fakeVictoryTaunt, 2.2f),
                    player = s.player.copy(shockedTimer = 0.7f, vx = -130f, vy = -220f)
                )
            } else {
                s = s.copy(fakeVictoryTimer = rem)
            }
            snapshot = s
            return s
        }

        if (s.phase != GamePhase.PLAYING) {
            jumpJustPressed = false
            snapshot = s
            return s
        }

        var player = s.player
        var toast = s.activeToast
        var shake = s.screenShake
        val spawnedParticles = s.particles.toMutableList()

        // 1. Check Control Flip Zone
        val playerCenterX = player.x + player.w * 0.5f
        val nowFlipped = s.level.controlFlipZones.any { playerCenterX in it.minX..it.maxX }
        if (nowFlipped && !s.controlsFlipped) {
            val zone = s.level.controlFlipZones.first { playerCenterX in it.minX..it.maxX }
            toast = TrollToast(zone.taunt, 1.8f)
            onEvent(GameEvent.TRAP_TRIGGERED)
            player = player.copy(shockedTimer = 0.5f)
        }

        val effLeft = if (nowFlipped) moveRightInput else moveLeftInput
        val effRight = if (nowFlipped) moveLeftInput else moveRightInput
        val moveDir = (if (effRight) 1f else 0f) - (if (effLeft) 1f else 0f)
        val hasMoved = s.hasMovedOnce || moveDir != 0f || jumpJustPressed

        // Horizontal movement (snappy arcade control)
        val targetVx = moveDir * MOVE_SPEED
        val accel = if (player.onGround) GROUND_ACCEL else AIR_ACCEL
        val newVx = approach(player.vx, targetVx, accel * dt)
        val facingRight = when {
            moveDir > 0f -> true
            moveDir < 0f -> false
            else -> player.facingRight
        }

        // Jump buffer + tight coyote time
        val newJumpBuffer = if (jumpJustPressed) {
            jumpJustPressed = false
            JUMP_BUFFER_TIME
        } else {
            (player.jumpBufferTimer - dt).coerceAtLeast(0f)
        }
        val newCoyote = if (player.onGround) COYOTE_TIME else (player.coyoteTimer - dt).coerceAtLeast(0f)

        var newVy = player.vy
        var onGround = player.onGround
        var finalJumpBuffer = newJumpBuffer
        var finalCoyote = newCoyote

        if (finalJumpBuffer > 0f && finalCoyote > 0f) {
            newVy = JUMP_VELOCITY
            onGround = false
            finalJumpBuffer = 0f
            finalCoyote = 0f
            onEvent(GameEvent.JUMP)
            // Foot dust puff
            repeat(5) {
                spawnedParticles.add(
                    Particle(
                        x = player.x + player.w * 0.5f + Random.nextFloat() * 10f - 5f,
                        y = player.y + player.h,
                        vx = Random.nextFloat() * 90f - 45f,
                        vy = -Random.nextFloat() * 60f - 15f,
                        size = 4f,
                        life = 0.25f,
                        maxLife = 0.25f,
                        color = Color(0xFFFFD6A5)
                    )
                )
            }
        }

        // Variable jump height when releasing jump early (feels great!)
        if (!jumpHeldInput && newVy < -190f) {
            newVy *= 0.72f
        }

        newVy = (newVy + GRAVITY * dt).coerceAtMost(MAX_FALL_SPEED)

        // 2. Update Platforms (Drop Traps, Crumble Tiles, Vanish-On-Touch, Rotate-On-Touch, Moving Snap)
        val platforms = s.platforms.map { rp ->
            if (!rp.active) return@map rp
            var next = rp
            val def = rp.def

            // Trigger check by X range
            if (!next.triggered && def.triggerMinX != null && def.triggerMaxX != null) {
                if (playerCenterX in def.triggerMinX..def.triggerMaxX) {
                    next = next.copy(triggered = true, timer = 0f)
                    if (def.tauntOnTrigger != null) {
                        toast = TrollToast(def.tauntOnTrigger, 1.5f)
                    }
                    onEvent(GameEvent.TRAP_TRIGGERED)
                    player = player.copy(shockedTimer = 0.45f)
                }
            }

            if (next.triggered) {
                val nt = next.timer + dt
                when (def.kind) {
                    PlatformKind.DROP_TRAP -> {
                        if (nt >= def.delaySec) {
                            val fv = (next.fallVelocity + 1600f * dt).coerceAtMost(780f)
                            val ny = next.y + fv * dt
                            next = next.copy(
                                timer = nt,
                                fallVelocity = fv,
                                y = ny,
                                shakeOffset = 0f,
                                active = ny < s.level.worldHeight + 120f
                            )
                        } else {
                            next = next.copy(
                                timer = nt,
                                shakeOffset = sin(nt * 95f) * 3.5f
                            )
                        }
                    }

                    PlatformKind.CRUMBLE -> {
                        if (nt >= def.crumbleSec) {
                            repeat(6) {
                                spawnedParticles.add(
                                    Particle(
                                        x = next.x + Random.nextFloat() * def.w,
                                        y = next.y + Random.nextFloat() * def.h,
                                        vx = Random.nextFloat() * 140f - 70f,
                                        vy = -Random.nextFloat() * 80f,
                                        size = 5f,
                                        life = 0.35f,
                                        maxLife = 0.35f,
                                        color = Color(0xFFD96B27)
                                    )
                                )
                            }
                            next = next.copy(timer = nt, active = false)
                        } else {
                            next = next.copy(
                                timer = nt,
                                shakeOffset = sin(nt * 110f) * 3f
                            )
                        }
                    }

                    PlatformKind.VANISH_ON_TOUCH -> {
                        if (nt >= def.vanishDelaySec) {
                            repeat(10) {
                                spawnedParticles.add(
                                    Particle(
                                        x = next.x + Random.nextFloat() * def.w,
                                        y = next.y + Random.nextFloat() * def.h,
                                        vx = Random.nextFloat() * 180f - 90f,
                                        vy = -Random.nextFloat() * 110f - 20f,
                                        size = 4.5f,
                                        life = 0.32f,
                                        maxLife = 0.32f,
                                        color = if (it % 2 == 0) Color(0xFFFFFFFF) else Color(0xFFFFA552)
                                    )
                                )
                            }
                            next = next.copy(timer = nt, active = false, vanishAlpha = 0f)
                        } else {
                            val progress = (nt / def.vanishDelaySec).coerceIn(0f, 1f)
                            next = next.copy(
                                timer = nt,
                                vanishAlpha = 1f - progress * 0.72f,
                                shakeOffset = sin(nt * 130f) * 2.5f
                            )
                        }
                    }

                    PlatformKind.ROTATE_ON_TOUCH -> {
                        val nextAngle = approach(next.rotationDeg, def.rotateTargetDeg, def.rotateSpeedDeg * dt)
                        next = next.copy(timer = nt, rotationDeg = nextAngle)
                    }

                    PlatformKind.MOVING_SNAP -> {
                        val nx = approach(next.x, def.targetX, def.moveSpeed * dt)
                        val ny = approach(next.y, def.targetY, def.moveSpeed * dt)
                        next = next.copy(timer = nt, x = nx, y = ny)
                    }

                    else -> next = next.copy(timer = nt)
                }
            }
            next
        }.toMutableList()

        // 3. Move Player X & Resolve Solid Collisions
        var px = (player.x + newVx * dt).coerceIn(0f, s.level.worldWidth - player.w)
        var py = player.y
        var finalVx = newVx

        for (i in platforms.indices) {
            val rp = platforms[i]
            if (!rp.active) continue
            if (rp.def.kind == PlatformKind.FAKE_SOLID) continue
            if (rp.def.kind == PlatformKind.INVISIBLE_BONK && !rp.revealed) continue
            // Once a rotating trapdoor tilts open past 32 deg, it no longer blocks horizontally
            if (rp.def.kind == PlatformKind.ROTATE_ON_TOUCH && abs(rp.rotationDeg) >= 32f) continue

            if (rectsOverlap(px, py, player.w, player.h, rp.x, rp.y, rp.def.w, rp.def.h)) {
                if (!rp.triggered && (rp.def.kind == PlatformKind.VANISH_ON_TOUCH || rp.def.kind == PlatformKind.ROTATE_ON_TOUCH)) {
                    platforms[i] = rp.copy(triggered = true, timer = 0f)
                    rp.def.tauntOnTrigger?.let { toast = TrollToast(it, 1.5f) }
                    onEvent(GameEvent.TRAP_TRIGGERED)
                    player = player.copy(shockedTimer = 0.45f)
                }
                if (finalVx > 0f) {
                    px = rp.x - player.w
                    finalVx = 0f
                } else if (finalVx < 0f) {
                    px = rp.x + rp.def.w
                    finalVx = 0f
                }
            }
        }

        // 4. Move Player Y & Resolve Vertical Collisions + Bonk / Crumble / Vanish / Rotate / Bounce / Fake Solid
        val prevBottom = py + player.h
        py += newVy * dt
        onGround = false
        var finalVy = newVy

        for (i in platforms.indices) {
            val rp = platforms[i]
            if (!rp.active) continue

            if (rectsOverlap(px, py, player.w, player.h, rp.x, rp.y, rp.def.w, rp.def.h)) {
                when (rp.def.kind) {
                    PlatformKind.FAKE_SOLID -> {
                        // Ghost bridge! Triggers translucent reveal and lets you fall right through!
                        if (!rp.triggered) {
                            platforms[i] = rp.copy(triggered = true)
                            rp.def.tauntOnTrigger?.let { toast = TrollToast(it, 1.5f) }
                            onEvent(GameEvent.TROLL_LAUGH)
                            player = player.copy(shockedTimer = 0.5f)
                        }
                    }

                    PlatformKind.INVISIBLE_BONK -> {
                        // Triggers ONLY when hitting from below (or once revealed, acts solid)
                        if (!rp.revealed) {
                            if (finalVy < 0f && py >= rp.y + rp.def.h * 0.4f) {
                                py = rp.y + rp.def.h
                                finalVy = 110f // Cruel downward bonk!
                                platforms[i] = rp.copy(revealed = true, triggered = true)
                                shake = 8f
                                rp.def.tauntOnTrigger?.let { toast = TrollToast(it, 1.6f) }
                                onEvent(GameEvent.TRAP_TRIGGERED)
                                player = player.copy(shockedTimer = 0.6f)
                            }
                        } else {
                            if (finalVy > 0f) {
                                py = rp.y - player.h
                                finalVy = 0f
                                onGround = true
                            } else if (finalVy < 0f) {
                                py = rp.y + rp.def.h
                                finalVy = 40f
                            }
                        }
                    }

                    PlatformKind.BOUNCE_TROLL -> {
                        if (finalVy >= 0f && prevBottom <= rp.y + 12f) {
                            py = rp.y - player.h
                            finalVy = BOUNCE_VELOCITY
                            onGround = false
                            shake = 5f
                            rp.def.tauntOnTrigger?.let { toast = TrollToast(it, 1.5f) }
                            onEvent(GameEvent.JUMP)
                            player = player.copy(shockedTimer = 0.45f)
                        }
                    }

                    PlatformKind.ROTATE_ON_TOUCH -> {
                        // Trigger rotation on ANY touch, then dump player off as trapdoor tilts past 36 deg!
                        val nowTriggered = if (!rp.triggered) {
                            platforms[i] = rp.copy(triggered = true, timer = 0f)
                            rp.def.tauntOnTrigger?.let { toast = TrollToast(it, 1.5f) }
                            onEvent(GameEvent.TRAP_TRIGGERED)
                            player = player.copy(shockedTimer = 0.5f)
                            true
                        } else true

                        if (nowTriggered && abs(rp.rotationDeg) < 36f) {
                            if (finalVy >= 0f && prevBottom <= rp.y + 14f) {
                                py = rp.y - player.h
                                finalVy = 0f
                                onGround = true
                                // Slip impulse in the direction the platform is tilting
                                val tiltDir = if (rp.def.rotateTargetDeg >= 0f) 1f else -1f
                                if (abs(rp.rotationDeg) > 10f) {
                                    finalVx += tiltDir * 140f * dt
                                }
                            } else if (finalVy < 0f) {
                                py = rp.y + rp.def.h
                                finalVy = 0f
                            }
                        }
                    }

                    PlatformKind.VANISH_ON_TOUCH -> {
                        // Looks 100% solid, triggers panic vanish the instant touched!
                        if (!rp.triggered) {
                            platforms[i] = rp.copy(triggered = true, timer = 0f)
                            rp.def.tauntOnTrigger?.let { toast = TrollToast(it, 1.5f) }
                            onEvent(GameEvent.TRAP_TRIGGERED)
                            player = player.copy(shockedTimer = 0.45f)
                        }
                        if (finalVy >= 0f && prevBottom <= rp.y + 14f) {
                            py = rp.y - player.h
                            finalVy = 0f
                            onGround = true
                        } else if (finalVy < 0f) {
                            py = rp.y + rp.def.h
                            finalVy = 0f
                        }
                    }

                    else -> {
                        if (finalVy >= 0f && prevBottom <= rp.y + 14f) {
                            py = rp.y - player.h
                            finalVy = 0f
                            onGround = true
                            // Trigger CRUMBLE or DROP_TRAP on step
                            if (!rp.triggered && (rp.def.kind == PlatformKind.CRUMBLE || rp.def.triggerOnStep)) {
                                platforms[i] = rp.copy(triggered = true, timer = 0f)
                                rp.def.tauntOnTrigger?.let { toast = TrollToast(it, 1.4f) }
                                onEvent(GameEvent.TRAP_TRIGGERED)
                            }
                        } else if (finalVy < 0f) {
                            py = rp.y + rp.def.h
                            finalVy = 0f
                        }
                    }
                }
            }
        }

        val updatedPlayerCenterX = px + player.w * 0.5f

        // 5. Update Spikes (Pop-up, Falling Ceiling, Sliding Ambush)
        val spikes = s.spikes.map { rs ->
            if (!rs.active) return@map rs
            var next = rs
            val def = rs.def
            if (!next.triggered && def.triggerMinX != null && def.triggerMaxX != null) {
                if (updatedPlayerCenterX in def.triggerMinX..def.triggerMaxX) {
                    next = next.copy(triggered = true, fallingActive = def.falling)
                    def.tauntOnTrigger?.let { toast = TrollToast(it, 1.5f) }
                    onEvent(GameEvent.TRAP_TRIGGERED)
                    player = player.copy(shockedTimer = 0.4f)
                }
            }
            if (next.triggered) {
                if (def.hiddenUntilTrigger && next.extension < 1f) {
                    next = next.copy(extension = (next.extension + dt * 11f).coerceAtMost(1f))
                }
                if (next.fallingActive) {
                    val ny = next.y + def.fallSpeed * dt
                    next = next.copy(y = ny, active = ny < s.level.worldHeight + 60f)
                }
                if (def.slideTargetX != null) {
                    val nx = approach(next.x, def.slideTargetX, def.slideSpeed * dt)
                    next = next.copy(x = nx)
                }
            }
            next
        }

        // 6. Update Flying Sniper Projectiles
        val projectiles = s.projectiles.map { rp ->
            if (!rp.active) return@map rp
            var next = rp
            if (!next.fired && updatedPlayerCenterX >= rp.def.triggerMinX) {
                next = next.copy(fired = true)
                rp.def.taunt?.let { toast = TrollToast(it, 1.5f) }
                onEvent(GameEvent.TRAP_TRIGGERED)
                player = player.copy(shockedTimer = 0.35f)
            }
            if (next.fired) {
                val nx = next.x + rp.def.vx * dt
                val ny = next.y + rp.def.vy * dt
                val inBounds = nx > -120f && nx < s.level.worldWidth + 120f
                next = next.copy(x = nx, y = ny, active = inBounds)
            }
            next
        }

        // 7. Update Chasing Saw Wall
        var nextSawX = s.sawX
        var nextSawAngle = s.sawAngle
        val sawDef = s.level.chasingSaw
        if (sawDef != null && nextSawX != null) {
            nextSawAngle = (nextSawAngle + dt * 520f) % 360f
            if (hasMoved && s.elapsedTime >= sawDef.wakeDelaySec) {
                if (nextSawX == sawDef.startX) {
                    toast = TrollToast(sawDef.taunt, 1.7f)
                    onEvent(GameEvent.TRAP_TRIGGERED)
                }
                nextSawX += sawDef.speed * dt
            }
        }

        // 8. Update Runaway Exit Door
        var door = s.exitDoor
        val doorDef = s.level.exitDoor
        if (doorDef.runawayTriggerDist != null && !door.hasRunAway) {
            val dist = hypot(
                (px + player.w * 0.5f) - (door.x + door.w * 0.5f),
                (py + player.h * 0.5f) - (door.y + door.h * 0.5f)
            )
            if (dist <= doorDef.runawayTriggerDist) {
                door = door.copy(isRunning = true, hasRunAway = true)
                toast = TrollToast(doorDef.runawayTaunt, 1.9f)
                onEvent(GameEvent.TROLL_LAUGH)
                player = player.copy(shockedTimer = 0.55f)
            }
        }
        if (door.isRunning) {
            val nx = approach(door.x, doorDef.runawayTargetX, 540f * dt)
            val ny = approach(door.y, doorDef.runawayTargetY, 440f * dt)
            val arrived = abs(nx - doorDef.runawayTargetX) < 1f && abs(ny - doorDef.runawayTargetY) < 1f
            door = door.copy(
                x = nx,
                y = ny,
                isRunning = !arrived,
                legPhase = door.legPhase + dt * 26f
            )
        }

        // 9. Hazard & Death Checks (with slight 3u forgiving hitbox inset on spikes)
        var deathCause: String? = null

        // Void fall
        if (py > s.level.worldHeight + 24f) {
            deathCause = "VOID"
        }

        // Spike collision
        if (deathCause == null) {
            for (rs in spikes) {
                if (!rs.active || rs.extension < 0.35f) continue
                val inset = 4f
                val activeH = rs.def.h * rs.extension
                val sy = if (rs.def.orientation == SpikeOrientation.UP) {
                    rs.y + (rs.def.h - activeH)
                } else rs.y
                if (rectsOverlap(
                        px + inset, py + inset, player.w - inset * 2, player.h - inset * 2,
                        rs.x + 3f, sy + 2f, (rs.def.w - 6f).coerceAtLeast(4f), (activeH - 4f).coerceAtLeast(4f)
                    )
                ) {
                    deathCause = "SPIKE"
                    break
                }
            }
        }

        // Projectile collision
        if (deathCause == null) {
            for (rp in projectiles) {
                if (!rp.active || !rp.fired) continue
                if (rectsOverlap(
                        px + 3f, py + 3f, player.w - 6f, player.h - 6f,
                        rp.x + 2f, rp.y + 2f, rp.def.w - 4f, rp.def.h - 4f
                    )
                ) {
                    deathCause = "SNIPER"
                    break
                }
            }
        }

        // Fake Checkpoint bomb collision!
        val checkpoints = s.fakeCheckpoints.toMutableList()
        if (deathCause == null) {
            for (i in checkpoints.indices) {
                val fc = checkpoints[i]
                if (!fc.exploded && rectsOverlap(
                        px + 2f, py + 2f, player.w - 4f, player.h - 4f,
                        fc.def.x, fc.def.y, fc.def.w, fc.def.h
                    )
                ) {
                    checkpoints[i] = fc.copy(exploded = true)
                    toast = TrollToast(fc.def.taunt, 2.0f)
                    deathCause = "FAKE_CHECKPOINT"
                    break
                }
            }
        }

        // Chasing Saw collision
        if (deathCause == null && nextSawX != null) {
            if (px < nextSawX + 26f) {
                deathCause = "SAW"
            }
        }

        // Camera follow smoothly
        val targetCamX = (px - VIEWPORT_WIDTH * 0.36f)
            .coerceIn(0f, (s.level.worldWidth - VIEWPORT_WIDTH).coerceAtLeast(0f))
        val nextCamX = s.cameraX + (targetCamX - s.cameraX) * (dt * 9.5f).coerceAtMost(1f)

        val nextPlayer = player.copy(
            x = px,
            y = py,
            vx = finalVx,
            vy = finalVy,
            facingRight = facingRight,
            onGround = onGround,
            coyoteTimer = finalCoyote,
            jumpBufferTimer = finalJumpBuffer,
            shockedTimer = (player.shockedTimer - dt).coerceAtLeast(0f),
            runCycle = if (onGround && abs(finalVx) > 20f) player.runCycle + dt * 16f else 0f
        )

        if (deathCause != null) {
            // Splat particle explosion!
            repeat(22) {
                val angle = Random.nextFloat() * 6.283f
                val spd = Random.nextFloat() * 240f + 70f
                spawnedParticles.add(
                    Particle(
                        x = px + player.w * 0.5f,
                        y = py + player.h * 0.5f,
                        vx = kotlin.math.cos(angle) * spd,
                        vy = kotlin.math.sin(angle) * spd - 90f,
                        size = Random.nextFloat() * 5f + 3f,
                        life = 0.55f,
                        maxLife = 0.55f,
                        color = if (it % 3 == 0) Color(0xFFFF2E54) else Color(0xFFFF7A1A)
                    )
                )
            }
            val msg = pickDeathMessage(s.level, deathCause)
            onEvent(GameEvent.DEATH)
            s = s.copy(
                phase = GamePhase.DEAD,
                player = nextPlayer.copy(alive = false),
                platforms = platforms,
                spikes = spikes,
                projectiles = projectiles,
                fakeCheckpoints = checkpoints,
                exitDoor = door,
                sawX = nextSawX,
                sawAngle = nextSawAngle,
                controlsFlipped = nowFlipped,
                cameraX = nextCamX,
                screenShake = 14f,
                particles = spawnedParticles,
                activeToast = toast,
                deathMessage = msg,
                deathCause = deathCause,
                elapsedTime = s.elapsedTime + dt,
                hasMovedOnce = hasMoved
            )
            snapshot = s
            return s
        }

        // 10. Check Exit Door Victory (or Fake Victory SIKE!)
        if (!door.isRunning && rectsOverlap(
                px, py, player.w, player.h,
                door.x + 4f, door.y + 4f, door.w - 8f, door.h - 6f
            )
        ) {
            if (doorDef.fakeVictoryTargetX != null && !door.fakeVictoryTriggered) {
                // FAKE VICTORY SIKE!
                onEvent(GameEvent.FAKE_CLEAR)
                s = s.copy(
                    phase = GamePhase.FAKE_VICTORY_SIKE,
                    fakeVictoryTimer = 0.72f,
                    player = nextPlayer,
                    platforms = platforms,
                    spikes = spikes,
                    projectiles = projectiles,
                    fakeCheckpoints = checkpoints,
                    exitDoor = door,
                    sawX = nextSawX,
                    sawAngle = nextSawAngle,
                    controlsFlipped = nowFlipped,
                    cameraX = nextCamX,
                    particles = spawnedParticles,
                    activeToast = TrollToast("LEVEL CLEAR!... WAIT A SEC", 0.7f),
                    elapsedTime = s.elapsedTime + dt,
                    hasMovedOnce = hasMoved
                )
                snapshot = s
                return s
            } else {
                // REAL LEVEL CLEAR!
                repeat(28) {
                    val angle = Random.nextFloat() * 6.283f
                    val spd = Random.nextFloat() * 260f + 80f
                    spawnedParticles.add(
                        Particle(
                            x = door.x + door.w * 0.5f,
                            y = door.y + door.h * 0.5f,
                            vx = kotlin.math.cos(angle) * spd,
                            vy = kotlin.math.sin(angle) * spd - 120f,
                            size = Random.nextFloat() * 5f + 3f,
                            life = 0.7f,
                            maxLife = 0.7f,
                            color = if (it % 2 == 0) Color(0xFF2EE578) else Color(0xFFFFD43B)
                        )
                    )
                }
                onEvent(GameEvent.LEVEL_CLEAR)
                s = s.copy(
                    phase = GamePhase.LEVEL_CLEAR,
                    player = nextPlayer,
                    platforms = platforms,
                    spikes = spikes,
                    projectiles = projectiles,
                    fakeCheckpoints = checkpoints,
                    exitDoor = door,
                    sawX = nextSawX,
                    sawAngle = nextSawAngle,
                    controlsFlipped = nowFlipped,
                    cameraX = nextCamX,
                    particles = spawnedParticles,
                    activeToast = null,
                    elapsedTime = s.elapsedTime + dt,
                    hasMovedOnce = hasMoved
                )
                snapshot = s
                return s
            }
        }

        s = s.copy(
            player = nextPlayer,
            platforms = platforms,
            spikes = spikes,
            projectiles = projectiles,
            fakeCheckpoints = checkpoints,
            exitDoor = door,
            sawX = nextSawX,
            sawAngle = nextSawAngle,
            controlsFlipped = nowFlipped,
            cameraX = nextCamX,
            screenShake = shake,
            particles = spawnedParticles,
            activeToast = toast,
            elapsedTime = s.elapsedTime + dt,
            hasMovedOnce = hasMoved
        )
        snapshot = s
        return s
    }

    private fun pickDeathMessage(level: LevelDefinition, cause: String): String {
        return when (cause) {
            "FAKE_CHECKPOINT" -> "HAHA! Nakli Checkpoint tha! 💥"
            "SAW" -> "Aari ne tumhe slice kar diya! ⚙️"
            else -> level.deathMessages.random()
        }
    }

    private fun approach(current: Float, target: Float, maxDelta: Float): Float {
        return when {
            current < target -> (current + maxDelta).coerceAtMost(target)
            current > target -> (current - maxDelta).coerceAtLeast(target)
            else -> target
        }
    }

    private fun rectsOverlap(
        ax: Float, ay: Float, aw: Float, ah: Float,
        bx: Float, by: Float, bw: Float, bh: Float
    ): Boolean {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by
    }
}
