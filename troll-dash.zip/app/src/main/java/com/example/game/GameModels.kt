package com.example.game

import androidx.compose.ui.graphics.Color

enum class PlatformKind {
    SOLID,
    DROP_TRAP,
    CRUMBLE,
    INVISIBLE_BONK,
    BOUNCE_TROLL,
    FAKE_SOLID,
    MOVING_SNAP,
    VANISH_ON_TOUCH,
    ROTATE_ON_TOUCH
}

enum class RotationPivot {
    CENTER,
    LEFT_EDGE,
    RIGHT_EDGE
}

enum class SpikeOrientation {
    UP, DOWN, LEFT, RIGHT
}

data class PlatformDef(
    val id: String,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val kind: PlatformKind = PlatformKind.SOLID,
    val triggerMinX: Float? = null,
    val triggerMaxX: Float? = null,
    val triggerOnStep: Boolean = false,
    val delaySec: Float = 0.08f,
    val crumbleSec: Float = 0.18f,
    val vanishDelaySec: Float = 0.09f,
    val rotateTargetDeg: Float = 90f,
    val rotateSpeedDeg: Float = 520f,
    val rotatePivot: RotationPivot = RotationPivot.LEFT_EDGE,
    val targetX: Float = x,
    val targetY: Float = y,
    val moveSpeed: Float = 380f,
    val hiddenUntilFakeWin: Boolean = false,
    val tauntOnTrigger: String? = null
)

data class SpikeDef(
    val id: String,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val orientation: SpikeOrientation = SpikeOrientation.UP,
    val hiddenUntilTrigger: Boolean = false,
    val triggerMinX: Float? = null,
    val triggerMaxX: Float? = null,
    val falling: Boolean = false,
    val fallSpeed: Float = 540f,
    val slideTargetX: Float? = null,
    val slideSpeed: Float = 360f,
    val tauntOnTrigger: String? = null
)

data class ProjectileTrapDef(
    val id: String,
    val startX: Float,
    val startY: Float,
    val w: Float = 26f,
    val h: Float = 14f,
    val vx: Float,
    val vy: Float = 0f,
    val triggerMinX: Float,
    val taunt: String? = null
)

data class FakeCheckpointDef(
    val id: String,
    val x: Float,
    val y: Float,
    val w: Float = 26f,
    val h: Float = 40f,
    val taunt: String = "HAHA NAKLI CHECKPOINT!"
)

data class ControlFlipZoneDef(
    val minX: Float,
    val maxX: Float,
    val taunt: String = "CONTROLS ULTE HO GAYE!"
)

data class ChasingSawDef(
    val startX: Float,
    val speed: Float,
    val wakeDelaySec: Float = 0.30f,
    val taunt: String = "PICHE DEKHO! BHAAG!"
)

data class ExitDoorDef(
    val x: Float,
    val y: Float,
    val w: Float = 34f,
    val h: Float = 46f,
    val runawayTriggerDist: Float? = null,
    val runawayTargetX: Float = x,
    val runawayTargetY: Float = y,
    val runawayTaunt: String = "BHAAG DOOR BHAAG!",
    val fakeVictoryTargetX: Float? = null,
    val fakeVictoryTargetY: Float? = null,
    val fakeVictoryTaunt: String = "SIKE! ASLI DOOR UPAR HAI!"
)

data class LevelDefinition(
    val number: Int,
    val title: String,
    val subtitle: String,
    val difficultySkulls: Int,
    val worldWidth: Float,
    val worldHeight: Float = 360f,
    val spawnX: Float,
    val spawnY: Float,
    val platforms: List<PlatformDef>,
    val spikes: List<SpikeDef>,
    val projectiles: List<ProjectileTrapDef> = emptyList(),
    val fakeCheckpoints: List<FakeCheckpointDef> = emptyList(),
    val controlFlipZones: List<ControlFlipZoneDef> = emptyList(),
    val chasingSaw: ChasingSawDef? = null,
    val exitDoor: ExitDoorDef,
    val accentColorHex: Long = 0xFFFF7A1A,
    val deathMessages: List<String>
)

// Runtime mutable-snapshot state classes rendered by GameCanvas
data class RuntimePlatform(
    val def: PlatformDef,
    val x: Float,
    val y: Float,
    val triggered: Boolean = false,
    val timer: Float = 0f,
    val active: Boolean = true,
    val revealed: Boolean = def.kind != PlatformKind.INVISIBLE_BONK && !def.hiddenUntilFakeWin,
    val shakeOffset: Float = 0f,
    val fallVelocity: Float = 0f,
    val rotationDeg: Float = 0f,
    val vanishAlpha: Float = 1f
)

data class RuntimeSpike(
    val def: SpikeDef,
    val x: Float,
    val y: Float,
    val triggered: Boolean = !def.hiddenUntilTrigger && !def.falling && def.slideTargetX == null,
    val extension: Float = if (def.hiddenUntilTrigger) 0f else 1f,
    val fallingActive: Boolean = false,
    val active: Boolean = true
)

data class RuntimeProjectile(
    val def: ProjectileTrapDef,
    val x: Float,
    val y: Float,
    val fired: Boolean = false,
    val active: Boolean = true
)

data class RuntimeFakeCheckpoint(
    val def: FakeCheckpointDef,
    val exploded: Boolean = false
)

data class RuntimeExitDoor(
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val isRunning: Boolean = false,
    val hasRunAway: Boolean = false,
    val fakeVictoryTriggered: Boolean = false,
    val legPhase: Float = 0f
)

data class Particle(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val size: Float,
    val life: Float,
    val maxLife: Float,
    val color: Color
)

data class TrollToast(
    val text: String,
    val remainingSec: Float
)

data class PlayerState(
    val x: Float,
    val y: Float,
    val vx: Float = 0f,
    val vy: Float = 0f,
    val w: Float = 24f,
    val h: Float = 24f,
    val facingRight: Boolean = true,
    val onGround: Boolean = false,
    val coyoteTimer: Float = 0f,
    val jumpBufferTimer: Float = 0f,
    val alive: Boolean = true,
    val shockedTimer: Float = 0f,
    val runCycle: Float = 0f
)

enum class GamePhase {
    PLAYING,
    DEAD,
    FAKE_VICTORY_SIKE,
    LEVEL_CLEAR
}

data class GameSnapshot(
    val level: LevelDefinition,
    val phase: GamePhase = GamePhase.PLAYING,
    val player: PlayerState,
    val platforms: List<RuntimePlatform>,
    val spikes: List<RuntimeSpike>,
    val projectiles: List<RuntimeProjectile>,
    val fakeCheckpoints: List<RuntimeFakeCheckpoint>,
    val exitDoor: RuntimeExitDoor,
    val sawX: Float? = null,
    val sawAngle: Float = 0f,
    val controlsFlipped: Boolean = false,
    val cameraX: Float = 0f,
    val screenShake: Float = 0f,
    val particles: List<Particle> = emptyList(),
    val activeToast: TrollToast? = null,
    val deathMessage: String = "",
    val deathCause: String = "",
    val elapsedTime: Float = 0f,
    val fakeVictoryTimer: Float = 0f,
    val hasMovedOnce: Boolean = false
)

enum class GameEvent {
    JUMP,
    DEATH,
    TRAP_TRIGGERED,
    TROLL_LAUGH,
    FAKE_CLEAR,
    LEVEL_CLEAR
}
