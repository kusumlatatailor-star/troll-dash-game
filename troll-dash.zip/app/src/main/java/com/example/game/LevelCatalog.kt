package com.example.game

/**
 * 10 handcrafted, ultra-tight, instant-reaction rage-bait 2D parkour levels built via
 * the declarative LevelLayoutBuilder DSL.
 * Features disguised safe-looking platforms that VANISH or ROTATE open on touch,
 * combined with zero-runway traps so the player barely has time to react.
 */
object LevelCatalog {

    val levels: List<LevelDefinition> = listOf(
        level1(),
        level2(),
        level3(),
        level4(),
        level5(),
        level6(),
        level7(),
        level8(),
        level9(),
        level10()
    )

    fun getLevel(number: Int): LevelDefinition =
        levels.firstOrNull { it.number == number } ?: levels.first()

    // LEVEL 1: Looks totally normal — first safe bridge ROTATES open like a trapdoor & a safe pad VANISHES on touch!
    private fun level1() = levelLayout(
        number = 1,
        title = "PEHLA DHOKA",
        subtitle = "Safe tiles rotate & vanish on touch.",
        difficultySkulls = 1,
        worldWidth = 780f,
        spawnX = 28f,
        spawnY = 240f,
        accentColorHex = 0xFFFF7A1A
    ) {
        solid(0f, 270f, 88f, 90f)
        // Disguised trapdoor! Looks 100% solid, swings open downward the instant you step on it!
        rotateOnTouch(
            x = 88f, y = 270f, w = 88f, h = 24f,
            targetDeg = 92f, speedDegPerSec = 510f, pivot = RotationPivot.LEFT_EDGE,
            taunt = "ZAMEEN GHOOM GAYI! 🌀"
        )
        solid(176f, 270f, 124f, 90f)
        solid(365f, 240f, 110f, 120f)
        // Disguised safe stepping stone that VANISHES milliseconds after touch!
        vanishOnTouch(
            x = 535f, y = 240f, w = 76f, h = 24f,
            vanishDelaySec = 0.11f,
            taunt = "POOF! BLOCK GAYAB! 💨"
        )
        dropTrap(
            x = 611f, y = 240f, w = 64f, h = 120f,
            triggerMinX = 592f, triggerMaxX = 685f, delaySec = 0.04f,
            taunt = "ITNE PAAS AAKE?! 💀"
        )
        solid(675f, 240f, 105f, 120f)

        popupSpike(224f, 250f, 36f, 20f, triggerMinX = 185f, triggerMaxX = 275f, taunt = "SURPRISE SPIKE!")
        spike(422f, 220f, 28f, 20f)

        exitDoor(x = 716f, y = 194f)
        deathMessages(
            "Level 1 mein hi nipat gaye? 😂",
            "Safe block samajh ke khade ho gaye!",
            "Zameen ghoom gayi, dimaag bhi!",
            "Touch kiya aur block gayab! 💨"
        )
    }

    // LEVEL 2: Falling ceiling spikes + spinning center-pivot trapdoor + jumping exit door!
    private fun level2() = levelLayout(
        number = 2,
        title = "CHHAT GIR RAHI HAI",
        subtitle = "Look up. Also your floor flips.",
        difficultySkulls = 2,
        worldWidth = 840f,
        spawnX = 26f,
        spawnY = 246f,
        accentColorHex = 0xFFFF2E54
    ) {
        solid(0f, 0f, 840f, 26f)
        solid(0f, 276f, 86f, 84f)
        solid(150f, 252f, 136f, 108f)
        // Looks completely solid — flips 95° around its center the moment you touch it!
        rotateOnTouch(
            x = 345f, y = 226f, w = 92f, h = 22f,
            targetDeg = 95f, speedDegPerSec = 540f, pivot = RotationPivot.CENTER,
            taunt = "FLOOR PALAT GAYA! 🌀"
        )
        solid(495f, 246f, 140f, 114f)
        solid(698f, 226f, 142f, 134f)

        fallingSpike(168f, 26f, 34f, 24f, triggerMinX = 128f, triggerMaxX = 215f, fallSpeed = 540f, taunt = "UPAR DEKHO! ⬇️")
        fallingSpike(242f, 26f, 34f, 24f, triggerMinX = 215f, triggerMaxX = 285f, fallSpeed = 570f)
        popupSpike(545f, 226f, 34f, 20f, triggerMinX = 505f, triggerMaxX = 590f, taunt = "NECHE BHI TRAP HAI!")
        fallingSpike(718f, 26f, 36f, 24f, triggerMinX = 678f, triggerMaxX = 760f, fallSpeed = 590f, taunt = "DOOR KE SAAMNE SLAM!")

        exitDoor(
            x = 776f, y = 180f,
            runawayTriggerDist = 64f,
            runawayTargetX = 776f,
            runawayTargetY = 126f,
            runawayTaunt = "KUUD KE PAKAD! ⬆️"
        )
        deathMessages(
            "Sir pe aasman gir gaya! ☄️",
            "Center pivot ne seedha neeche fenka!",
            "Helmet pehen ke aana tha!",
            "Chhat aur zameen dono dushman!"
        )
    }

    // LEVEL 3: Gayab Zameen — Back-to-back disguised VANISH & ROTATE stepping stones + Invisible Bonk!
    private fun level3() = levelLayout(
        number = 3,
        title = "GAYAB ZAMEEN",
        subtitle = "Every safe-looking stone betrays you.",
        difficultySkulls = 2,
        worldWidth = 860f,
        spawnX = 24f,
        spawnY = 244f,
        accentColorHex = 0xFF9B5DE5
    ) {
        solid(0f, 274f, 76f, 86f)
        // Safe-looking stone #1 -> VANISHES right after you touch it!
        vanishOnTouch(136f, 262f, 66f, 22f, vanishDelaySec = 0.11f, taunt = "TOUCH KIYA, GAYAB HUA! 💨")
        fakeSolid(216f, 262f, 64f, 22f, taunt = "HAVA THI WOH! 👻")
        solid(292f, 248f, 84f, 112f)
        invisibleBonk(390f, 168f, 36f, 26f, taunt = "BONK! SIR PHUTA! 🤕")
        // Safe-looking stone #2 -> ROTATES open from right hinge!
        rotateOnTouch(
            x = 448f, y = 248f, w = 72f, h = 22f,
            targetDeg = -92f, speedDegPerSec = 520f, pivot = RotationPivot.RIGHT_EDGE,
            taunt = "ULTA TRAPDOOR! 🌀"
        )
        // Safe-looking stone #3 -> VANISHES on touch!
        vanishOnTouch(582f, 224f, 70f, 22f, vanishDelaySec = 0.10f, taunt = "RUKNA MANA HAI! 💨")
        invisibleBonk(672f, 138f, 34f, 24f, taunt = "PHIR SE BONK! 😂")
        solid(726f, 224f, 134f, 136f)

        popupSpike(326f, 228f, 28f, 20f, triggerMinX = 300f, triggerMaxX = 360f)
        popupSpike(756f, 204f, 28f, 20f, triggerMinX = 720f, triggerMaxX = 795f, taunt = "LAST SECOND KAANTA!")

        exitDoor(x = 808f, y = 178f)
        deathMessages(
            "Invisible block ne chuma maara! 😘",
            "Safe lag raha tha na? Gayab ho gaya!",
            "Rukoge toh giroge!",
            "Dimag mein lag gaya BONK!"
        )
    }

    // LEVEL 4: Bhaag Door Bhaag — Runaway Exit + Rotating bridge ambush!
    private fun level4() = levelLayout(
        number = 4,
        title = "BHAAG DOOR BHAAG",
        subtitle = "Catch the exit across spinning traps.",
        difficultySkulls = 3,
        worldWidth = 940f,
        spawnX = 24f,
        spawnY = 244f,
        accentColorHex = 0xFF2EE578
    ) {
        solid(0f, 274f, 76f, 86f)
        solid(142f, 250f, 86f, 110f)
        rotateOnTouch(
            x = 228f, y = 250f, w = 68f, h = 22f,
            targetDeg = 92f, speedDegPerSec = 540f, pivot = RotationPivot.LEFT_EDGE,
            taunt = "TRAPDOOR KHULA! 🌀"
        )
        solid(358f, 232f, 128f, 128f)
        vanishOnTouch(554f, 232f, 68f, 22f, vanishDelaySec = 0.11f, taunt = "BRIDGE GAYAB! 💨")
        solid(686f, 212f, 74f, 148f)
        solid(826f, 212f, 114f, 148f)

        slidingSpike(198f, 230f, 26f, 20f, triggerMinX = 130f, triggerMaxX = 225f, slideTargetX = 148f, slideSpeed = 300f, taunt = "SPIKE BHI CHALTA HAI!")
        popupSpike(442f, 212f, 34f, 20f, triggerMinX = 408f, triggerMaxX = 486f, taunt = "DOOR GAYA, SPIKE AAYA!")
        popupSpike(712f, 192f, 28f, 20f, triggerMinX = 682f, triggerMaxX = 755f)

        exitDoor(
            x = 436f, y = 186f,
            runawayTriggerDist = 66f,
            runawayTargetX = 876f,
            runawayTargetY = 166f,
            runawayTaunt = "TATA BYE-BYE! PAKAD LE! 🏃"
        )
        deathMessages(
            "Door bol ke gaya: 'Nahi milunga!' 🏃",
            "Safe bridge ghoom ke dhoka de gaya!",
            "Door bhaag gaya, tum gir gaye!",
            "Speed badhao beta!"
        )
    }

    // LEVEL 5: Ulta Dimaag — Controls flip mid-gauntlet + deceptive rotating exit approach!
    private fun level5() = levelLayout(
        number = 5,
        title = "ULTA DIMAAG",
        subtitle = "Left is Right. Floor tilts too.",
        difficultySkulls = 3,
        worldWidth = 900f,
        spawnX = 24f,
        spawnY = 244f,
        accentColorHex = 0xFF29D4FF
    ) {
        solid(0f, 274f, 78f, 86f)
        solid(140f, 254f, 128f, 106f)
        solid(336f, 254f, 122f, 106f)
        solid(522f, 232f, 124f, 128f)
        rotateOnTouch(
            x = 646f, y = 232f, w = 64f, h = 22f,
            targetDeg = 94f, speedDegPerSec = 550f, pivot = RotationPivot.LEFT_EDGE,
            taunt = "NORMAL HUA AUR PALAT GAYA! 🌀"
        )
        solid(760f, 224f, 140f, 136f)

        spike(198f, 234f, 28f, 20f)
        popupSpike(388f, 234f, 30f, 20f, triggerMinX = 345f, triggerMaxX = 435f)
        spike(566f, 212f, 28f, 20f)
        popupSpike(784f, 204f, 28f, 20f, triggerMinX = 755f, triggerMaxX = 825f)

        flipZone(235f, 645f, taunt = "LEFT ↔ RIGHT ULTA! 🤪")
        exitDoor(x = 842f, y = 178f)
        deathMessages(
            "Brain.exe has stopped working! 🤯",
            "Left dabaya ya Right? Khud nahi pata!",
            "Ulte controls mein seedha khadde mein!",
            "Dimaag ka dahi ho gaya!"
        )
    }

    // LEVEL 6: Nakli Checkpoint — Fake save flags + disguised vanishing & rotating bridges!
    private fun level6() = levelLayout(
        number = 6,
        title = "NAKLI CHECKPOINT",
        subtitle = "Trust nobody. Not even the floor.",
        difficultySkulls = 3,
        worldWidth = 920f,
        spawnX = 24f,
        spawnY = 244f,
        accentColorHex = 0xFFFFD43B
    ) {
        solid(0f, 274f, 76f, 86f)
        vanishOnTouch(138f, 254f, 72f, 22f, vanishDelaySec = 0.11f, taunt = "SAFE NAHI THA! 💨")
        solid(272f, 254f, 150f, 106f)
        solid(488f, 228f, 146f, 132f)
        rotateOnTouch(
            x = 698f, y = 228f, w = 68f, h = 22f,
            targetDeg = 94f, speedDegPerSec = 540f, pivot = RotationPivot.CENTER,
            taunt = "SPIN TRAP! 🌀"
        )
        solid(818f, 216f, 102f, 144f)

        popupSpike(282f, 234f, 26f, 20f, triggerMinX = 250f, triggerMaxX = 320f)
        popupSpike(596f, 208f, 28f, 20f, triggerMinX = 560f, triggerMaxX = 630f)

        fakeCheckpoint(354f, 214f, taunt = "HAHA NAKLI CHECKPOINT! 💥")
        fakeCheckpoint(538f, 188f, taunt = "DOOBARA FASS GAYE?! 😂")

        exitDoor(x = 856f, y = 170f)
        deathMessages(
            "Checkpoint samajh ke gale lag liya! 💀",
            "Green flag dekh ke pighal gaye?",
            "Yahan koi save nahi milta bhai!",
            "Jump karna tha uske upar se!"
        )
    }

    // LEVEL 7: Piche Dekho! — Chasing saw wall + vanishing & tilting bridges forcing nonstop sprints!
    private fun level7() = levelLayout(
        number = 7,
        title = "PICHE DEKHO!",
        subtitle = "Saw behind, vanishing floor below.",
        difficultySkulls = 4,
        worldWidth = 1040f,
        spawnX = 54f,
        spawnY = 244f,
        accentColorHex = 0xFFFF2E54
    ) {
        solid(0f, 274f, 106f, 86f)
        solid(172f, 260f, 96f, 100f)
        vanishOnTouch(336f, 244f, 76f, 22f, vanishDelaySec = 0.13f, taunt = "BHAAG! FLOOR GAYAB! 💨")
        solid(480f, 244f, 118f, 116f)
        rotateOnTouch(
            x = 666f, y = 222f, w = 78f, h = 22f,
            targetDeg = 92f, speedDegPerSec = 480f, pivot = RotationPivot.LEFT_EDGE,
            taunt = "TILTING BRIDGE! 🌀"
        )
        solid(812f, 222f, 76f, 138f)
        solid(942f, 210f, 98f, 150f)

        spike(216f, 240f, 26f, 20f)
        popupSpike(528f, 224f, 28f, 20f, triggerMinX = 485f, triggerMaxX = 570f)
        spike(838f, 202f, 24f, 20f)

        chasingSaw(startX = -56f, speed = 162f, wakeDelaySec = 0.25f)
        exitDoor(x = 978f, y = 164f)
        deathMessages(
            "Aari ne pakoda bana diya! ⚙️",
            "Ruk ke kya soch rahe the?!",
            "Bhaag Milkha Bhaag slow pad gaya!",
            "Chasing saw ko zero mercy hai!"
        )
    }

    // LEVEL 8: Udta Teer — Sniper flying spikes, troll trampoline, & vanishing escape stone!
    private fun level8() = levelLayout(
        number = 8,
        title = "UDTA TEER",
        subtitle = "Dodge snipers, trampolines & ghost tiles.",
        difficultySkulls = 4,
        worldWidth = 960f,
        spawnX = 24f,
        spawnY = 246f,
        accentColorHex = 0xFFFF9F1C
    ) {
        solid(0f, 0f, 960f, 24f)
        solid(0f, 276f, 82f, 84f)
        solid(148f, 256f, 118f, 104f)
        bouncePad(336f, 268f, 52f, 20f, taunt = "BOING! CHHAT SE BACHO!")
        solid(456f, 210f, 128f, 150f)
        vanishOnTouch(652f, 224f, 74f, 22f, vanishDelaySec = 0.11f, taunt = "POOF! QUICK JUMP! 💨")
        solid(794f, 216f, 166f, 144f)

        spike(326f, 24f, 70f, 24f, orientation = SpikeOrientation.DOWN)
        popupSpike(832f, 196f, 28f, 20f, triggerMinX = 790f, triggerMaxX = 875f)

        sniper(430f, 234f, vx = -310f, triggerMinX = 148f, taunt = "UDTA TEER AAYA! 🎯")
        sniper(780f, 186f, vx = -340f, triggerMinX = 472f, taunt = "JUMP KAR! SNIPER!")
        sniper(955f, 194f, vx = -320f, triggerMinX = 795f, taunt = "LAST SECOND TEER!")

        exitDoor(x = 898f, y = 170f)
        deathMessages(
            "Udta teer seedha dil pe laga! 🎯",
            "Trampoline dost nahi dushman tha!",
            "Sniper ne 360 no-scope maar diya!",
            "Duck nahi, JUMP karna tha!"
        )
    }

    // LEVEL 9: Fake Victory?! — Spinning start pad + Fake Clear SIKE! + Upper climb!
    private fun level9() = levelLayout(
        number = 9,
        title = "FAKE VICTORY?!",
        subtitle = "Never celebrate early.",
        difficultySkulls = 4,
        worldWidth = 860f,
        spawnX = 24f,
        spawnY = 250f,
        accentColorHex = 0xFF00F5D4
    ) {
        solid(0f, 280f, 78f, 80f)
        rotateOnTouch(
            x = 142f, y = 266f, w = 72f, h = 22f,
            targetDeg = 92f, speedDegPerSec = 520f, pivot = RotationPivot.CENTER,
            taunt = "FLIP BRIDGE! 🌀"
        )
        solid(280f, 256f, 108f, 104f)
        solid(456f, 240f, 114f, 120f)
        solid(636f, 240f, 184f, 120f)
        // Revealed after Fake Victory SIKE!
        solid(576f, 182f, 76f, 20f, hiddenUntilFakeWin = true)
        solid(690f, 134f, 138f, 20f, hiddenUntilFakeWin = true)

        popupSpike(318f, 236f, 28f, 20f, triggerMinX = 280f, triggerMaxX = 365f)
        slidingSpike(498f, 220f, 30f, 20f, triggerMinX = 450f, triggerMaxX = 560f, slideTargetX = 466f, slideSpeed = 280f)
        popupSpike(718f, 114f, 26f, 20f, triggerMinX = 688f, triggerMaxX = 760f)

        fakeCheckpoint(356f, 216f, taunt = "SAVE? SAPNE DEKHO! 💥")

        exitDoor(
            x = 736f, y = 194f,
            fakeVictoryTargetX = 778f,
            fakeVictoryTargetY = 88f,
            fakeVictoryTaunt = "SIKE! ASLI DOOR UPAR HAI! 😈"
        )
        deathMessages(
            "Khush ho gaye the na?! 😂",
            "Fake victory mein bharosa kar liya!",
            "Picture abhi baaki hai mere dost!",
            "Upar chadho, neeche sirf dhoka hai!"
        )
    }

    // LEVEL 10: Baap Of All Trolls — Every deceptive platform & troll combined!
    private fun level10() = levelLayout(
        number = 10,
        title = "BAAP OF ALL TROLLS",
        subtitle = "Vanish, rotate, bonk, flip — survive all.",
        difficultySkulls = 5,
        worldWidth = 1120f,
        spawnX = 24f,
        spawnY = 248f,
        accentColorHex = 0xFFFF2E54
    ) {
        solid(0f, 0f, 1120f, 22f)
        solid(0f, 278f, 74f, 82f)
        // Instant disguised rotating trapdoor right next to spawn!
        rotateOnTouch(
            x = 74f, y = 278f, w = 68f, h = 24f,
            targetDeg = 94f, speedDegPerSec = 560f, pivot = RotationPivot.LEFT_EDGE,
            taunt = "WELCOME TO LEVEL 10! 🌀"
        )
        solid(156f, 260f, 112f, 100f)
        invisibleBonk(282f, 170f, 32f, 24f, taunt = "BONK AGAIN! 🤕")
        // Safe-looking vanishing stone!
        vanishOnTouch(336f, 248f, 68f, 22f, vanishDelaySec = 0.10f, taunt = "POOF! 💨")
        solid(470f, 248f, 146f, 112f)
        solid(684f, 232f, 134f, 128f)
        // Final rotating trapdoor before the runaway exit!
        rotateOnTouch(
            x = 884f, y = 220f, w = 68f, h = 22f,
            targetDeg = -94f, speedDegPerSec = 550f, pivot = RotationPivot.RIGHT_EDGE,
            taunt = "AAKHIRI SPIN TRAP! 🌀"
        )
        solid(988f, 212f, 132f, 148f)

        fallingSpike(198f, 22f, 34f, 24f, triggerMinX = 152f, triggerMaxX = 240f, fallSpeed = 570f)
        popupSpike(528f, 228f, 30f, 20f, triggerMinX = 485f, triggerMaxX = 575f)
        popupSpike(1010f, 192f, 28f, 20f, triggerMinX = 992f, triggerMaxX = 1048f, taunt = "FINAL DHOKA! 💀")

        sniper(970f, 206f, vx = -335f, triggerMinX = 690f, taunt = "SNIPER FINALE! 🎯")
        fakeCheckpoint(738f, 192f, taunt = "LEVEL 10 MEIN SAVE? HAHA!")
        flipZone(468f, 620f, taunt = "ULTA BRAIN MODE! 🤪")

        exitDoor(
            x = 1004f, y = 166f,
            runawayTriggerDist = 52f,
            runawayTargetX = 1074f,
            runawayTargetY = 166f,
            runawayTaunt = "EK AAKHIRI BAAR BHAAG! 🏃"
        )
        deathMessages(
            "Level 10 sabka baap hai! 👑",
            "Phone mat fekna bhai! 📱",
            "Spinning trapdoors se bacho!",
            "Almost! Bas thoda aur rage!"
        )
    }
}
