package com.example.ui.game

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Dangerous
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.game.GameEngine
import com.example.game.GameEvent
import com.example.game.GamePhase
import com.example.game.LevelCatalog
import com.example.ui.theme.DungeonBorder
import com.example.ui.theme.DungeonCard
import com.example.ui.theme.DungeonElevated
import com.example.ui.theme.DungeonSurface
import com.example.ui.theme.DungeonVoid
import com.example.ui.theme.ExitEmerald
import com.example.ui.theme.FakeGold
import com.example.ui.theme.FlipCyan
import com.example.ui.theme.RunnerOrange
import com.example.ui.theme.SpikeCrimson
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GameScreen(
    levelNumber: Int,
    levelDeaths: Int,
    deathGeneration: Int,
    soundEnabled: Boolean,
    hapticsEnabled: Boolean,
    onGameEvent: (GameEvent) -> Unit,
    onButtonDodged: () -> Unit,
    onToggleSound: () -> Unit,
    onNextLevel: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val haptic = LocalHapticFeedback.current
    val levelDef = remember(levelNumber) { LevelCatalog.getLevel(levelNumber) }
    val currentOnGameEvent by rememberUpdatedState(onGameEvent)
    val currentHapticsEnabled by rememberUpdatedState(hapticsEnabled)

    val engine = remember(levelNumber) {
        GameEngine(levelDef) { evt ->
            currentOnGameEvent(evt)
            if (currentHapticsEnabled && evt == GameEvent.DEATH) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
        }
    }

    var snapshot by remember(levelNumber) { mutableStateOf(engine.snapshot) }
    var leftHeld by remember(levelNumber) { mutableStateOf(false) }
    var rightHeld by remember(levelNumber) { mutableStateOf(false) }
    var jumpHeld by remember(levelNumber) { mutableStateOf(false) }

    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(levelNumber) {
        runCatching { focusRequester.requestFocus() }
    }

    // Smooth 60fps game loop driven by Compose frame clock
    LaunchedEffect(engine) {
        var lastFrameNs = 0L
        while (true) {
            withFrameNanos { frameNs ->
                if (lastFrameNs == 0L) {
                    lastFrameNs = frameNs
                } else {
                    val dt = (frameNs - lastFrameNs) / 1_000_000_000f
                    lastFrameNs = frameNs
                    snapshot = engine.step(dt)
                }
            }
        }
    }

    fun respawnNow() {
        leftHeld = false
        rightHeld = false
        jumpHeld = false
        engine.resetCurrentLevel()
        snapshot = engine.snapshot
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(DungeonVoid)
            .focusRequester(focusRequester)
            .focusable()
            .onPreviewKeyEvent { keyEvent ->
                val isDown = keyEvent.type == KeyEventType.KeyDown
                val isUp = keyEvent.type == KeyEventType.KeyUp
                if (!isDown && !isUp) return@onPreviewKeyEvent false
                when (keyEvent.key) {
                    Key.DirectionLeft, Key.A -> {
                        leftHeld = isDown
                        engine.setMoveLeft(isDown)
                        true
                    }
                    Key.DirectionRight, Key.D -> {
                        rightHeld = isDown
                        engine.setMoveRight(isDown)
                        true
                    }
                    Key.Spacebar, Key.W, Key.DirectionUp -> {
                        jumpHeld = isDown
                        engine.setJump(isDown)
                        true
                    }
                    else -> false
                }
            }
    ) {
        val isWideLayout = maxWidth > maxHeight

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Top Arcade HUD
            GameHudBar(
                levelNumber = levelDef.number,
                levelTitle = levelDef.title,
                levelDeaths = levelDeaths,
                controlsFlipped = snapshot.controlsFlipped,
                soundEnabled = soundEnabled,
                onBack = onBack,
                onToggleSound = onToggleSound,
                onRestart = { respawnNow() }
            )

            // Main Stage Area (Canvas + Overlays)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(if (isWideLayout) 1f else 0.72f)
            ) {
                GameCanvas(
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxSize()
                )

                // Mid-game Sarcastic Troll Toast Banner
                val toast = snapshot.activeToast
                androidx.compose.animation.AnimatedVisibility(
                    visible = toast != null && snapshot.phase == GamePhase.PLAYING,
                    enter = fadeIn() + scaleIn(initialScale = 0.85f),
                    exit = fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 10.dp, start = 16.dp, end = 16.dp)
                ) {
                    toast?.let {
                        Surface(
                            color = DungeonCard.copy(alpha = 0.94f),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.5.dp, FakeGold)
                        ) {
                            Text(
                                text = it.text,
                                style = MaterialTheme.typography.labelLarge,
                                color = FakeGold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                            )
                        }
                    }
                }

                // Controls-Flipped Warning Pill
                if (snapshot.controlsFlipped && snapshot.phase == GamePhase.PLAYING) {
                    Surface(
                        color = FlipCyan.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, FlipCyan),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SwapHoriz,
                                contentDescription = null,
                                tint = FlipCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = stringResource(R.string.controls_flipped_badge),
                                style = MaterialTheme.typography.labelMedium,
                                color = FlipCyan
                            )
                        }
                    }
                }

                // FAKE VICTORY SIKE OVERLAY (Level 9!)
                if (snapshot.phase == GamePhase.FAKE_VICTORY_SIKE) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ExitEmerald.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            color = DungeonCard,
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(2.5.dp, ExitEmerald)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 28.dp, vertical = 18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.EmojiEvents,
                                    contentDescription = null,
                                    tint = FakeGold,
                                    modifier = Modifier.size(40.dp)
                                )
                                Text(
                                    text = stringResource(R.string.level_clear_title),
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = ExitEmerald
                                )
                            }
                        }
                    }
                }

                // SIGNATURE RUNAWAY DEATH OVERLAY (Stationary on Death #1, Fleeing on Death #2+!)
                if (snapshot.phase == GamePhase.DEAD) {
                    RunawayDeathOverlay(
                        levelDeaths = levelDeaths.coerceAtLeast(1),
                        deathGeneration = deathGeneration,
                        deathMessage = snapshot.deathMessage,
                        hapticsEnabled = hapticsEnabled,
                        onButtonDodged = onButtonDodged,
                        onRespawn = { respawnNow() }
                    )
                }

                // REAL LEVEL CLEAR OVERLAY
                if (snapshot.phase == GamePhase.LEVEL_CLEAR) {
                    LevelClearOverlay(
                        levelNumber = levelDef.number,
                        levelTitle = levelDef.title,
                        deathsThisLevel = levelDeaths,
                        onReplay = { respawnNow() },
                        onNextLevel = onNextLevel
                    )
                }

                // Landscape overlay controls inside the stage corners
                if (isWideLayout && snapshot.phase == GamePhase.PLAYING) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ArcadeControlPad(
                                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = stringResource(R.string.move_left_desc),
                                pressed = leftHeld,
                                accentColor = if (snapshot.controlsFlipped) FlipCyan else RunnerOrange,
                                compact = true,
                                testTag = "btn_left",
                                onPressedChange = { down ->
                                    leftHeld = down
                                    engine.setMoveLeft(down)
                                }
                            )
                            ArcadeControlPad(
                                icon = Icons.AutoMirrored.Rounded.ArrowForward,
                                contentDescription = stringResource(R.string.move_right_desc),
                                pressed = rightHeld,
                                accentColor = if (snapshot.controlsFlipped) FlipCyan else RunnerOrange,
                                compact = true,
                                testTag = "btn_right",
                                onPressedChange = { down ->
                                    rightHeld = down
                                    engine.setMoveRight(down)
                                }
                            )
                        }

                        ArcadeControlPad(
                            icon = Icons.Rounded.ArrowUpward,
                            contentDescription = stringResource(R.string.jump_desc),
                            pressed = jumpHeld,
                            accentColor = ExitEmerald,
                            compact = true,
                            isJump = true,
                            testTag = "btn_jump",
                            onPressedChange = { down ->
                                jumpHeld = down
                                engine.setJump(down)
                                if (down && hapticsEnabled) {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                        )
                    }
                }
            }

            // Portrait dedicated ergonomic arcade thumb deck
            if (!isWideLayout) {
                Surface(
                    color = DungeonSurface,
                    border = BorderStroke(1.dp, DungeonBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.28f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = levelDef.subtitle,
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ArcadeControlPad(
                                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = stringResource(R.string.move_left_desc),
                                    pressed = leftHeld,
                                    accentColor = if (snapshot.controlsFlipped) FlipCyan else RunnerOrange,
                                    compact = false,
                                    testTag = "btn_left",
                                    onPressedChange = { down ->
                                        leftHeld = down
                                        engine.setMoveLeft(down)
                                    }
                                )
                                ArcadeControlPad(
                                    icon = Icons.AutoMirrored.Rounded.ArrowForward,
                                    contentDescription = stringResource(R.string.move_right_desc),
                                    pressed = rightHeld,
                                    accentColor = if (snapshot.controlsFlipped) FlipCyan else RunnerOrange,
                                    compact = false,
                                    testTag = "btn_right",
                                    onPressedChange = { down ->
                                        rightHeld = down
                                        engine.setMoveRight(down)
                                    }
                                )
                            }

                            ArcadeControlPad(
                                icon = Icons.Rounded.ArrowUpward,
                                contentDescription = stringResource(R.string.jump_desc),
                                pressed = jumpHeld,
                                accentColor = ExitEmerald,
                                compact = false,
                                isJump = true,
                                testTag = "btn_jump",
                                onPressedChange = { down ->
                                    jumpHeld = down
                                    engine.setJump(down)
                                    if (down && hapticsEnabled) {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameHudBar(
    levelNumber: Int,
    levelTitle: String,
    levelDeaths: Int,
    controlsFlipped: Boolean,
    soundEnabled: Boolean,
    onBack: () -> Unit,
    onToggleSound: () -> Unit,
    onRestart: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DungeonSurface)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.testTag("hud_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = stringResource(R.string.navigate_back_desc),
                tint = TextPrimary
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = if (controlsFlipped) FlipCyan else RunnerOrange,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "LVL $levelNumber/10",
                        style = MaterialTheme.typography.labelSmall,
                        color = DungeonVoid,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Text(
                    text = levelTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Death Counter Chip
        Surface(
            color = DungeonCard,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, if (levelDeaths >= 2) SpikeCrimson else DungeonBorder)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Dangerous,
                    contentDescription = null,
                    tint = SpikeCrimson,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "$levelDeaths",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary
                )
            }
        }

        IconButton(
            onClick = onToggleSound,
            modifier = Modifier.testTag("hud_sound_button")
        ) {
            Icon(
                imageVector = if (soundEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                contentDescription = stringResource(
                    if (soundEnabled) R.string.sound_on_desc else R.string.sound_off_desc
                ),
                tint = if (soundEnabled) TextPrimary else TextSecondary
            )
        }

        IconButton(
            onClick = onRestart,
            modifier = Modifier.testTag("hud_restart_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.Refresh,
                contentDescription = stringResource(R.string.restart_level_desc),
                tint = RunnerOrange
            )
        }
    }
}

@Composable
private fun ArcadeControlPad(
    icon: ImageVector,
    contentDescription: String,
    pressed: Boolean,
    accentColor: Color,
    compact: Boolean,
    isJump: Boolean = false,
    testTag: String,
    onPressedChange: (Boolean) -> Unit
) {
    val sizeDp = when {
        compact && isJump -> 74.dp
        compact -> 66.dp
        isJump -> 88.dp
        else -> 76.dp
    }
    val shape = if (isJump) CircleShape else RoundedCornerShape(20.dp)
    val bgColor = if (pressed) accentColor.copy(alpha = 0.35f) else DungeonElevated.copy(alpha = 0.88f)
    val borderColor = if (pressed) accentColor else DungeonBorder

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(sizeDp)
            .clip(shape)
            .background(bgColor)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        when (event.type) {
                            PointerEventType.Press -> {
                                onPressedChange(true)
                                event.changes.forEach { it.consume() }
                            }
                            PointerEventType.Release -> {
                                val anyStillDown = event.changes.any { it.pressed }
                                onPressedChange(anyStillDown)
                                event.changes.forEach { it.consume() }
                            }
                            PointerEventType.Exit -> {
                                onPressedChange(false)
                            }
                            else -> Unit
                        }
                    }
                }
            }
            .testTag(testTag)
    ) {
        Surface(
            color = Color.Transparent,
            shape = shape,
            border = BorderStroke(2.5.dp, borderColor),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = contentDescription,
                    tint = if (pressed) accentColor else TextPrimary,
                    modifier = Modifier.size(if (isJump) 38.dp else 34.dp)
                )
            }
        }
    }
}

@Composable
private fun LevelClearOverlay(
    levelNumber: Int,
    levelTitle: String,
    deathsThisLevel: Int,
    onReplay: () -> Unit,
    onNextLevel: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(DungeonVoid.copy(alpha = 0.78f), DungeonVoid.copy(alpha = 0.90f))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = DungeonCard,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(2.dp, ExitEmerald),
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Rounded.EmojiEvents,
                    contentDescription = null,
                    tint = FakeGold,
                    modifier = Modifier.size(44.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.level_clear_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = ExitEmerald
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "LVL $levelNumber • $levelTitle",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (deathsThisLevel == 0) {
                        "0 DEATHS?! HACKER HAI KYA?! 🔥"
                    } else {
                        "Survived after $deathsThisLevel troll death${if (deathsThisLevel == 1) "" else "s"}!"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = FakeGold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(18.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = onReplay,
                        border = BorderStroke(1.5.dp, DungeonBorder),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(0.42f)
                            .height(50.dp)
                            .testTag("clear_replay_button")
                    ) {
                        Text(
                            text = stringResource(R.string.replay_cta),
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }
                    Button(
                        onClick = onNextLevel,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ExitEmerald,
                            contentColor = DungeonVoid
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(0.58f)
                            .height(50.dp)
                            .testTag("clear_next_level_button")
                    ) {
                        Text(
                            text = if (levelNumber >= 10) "CLAIM CROWN" else stringResource(R.string.next_level_cta),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}
