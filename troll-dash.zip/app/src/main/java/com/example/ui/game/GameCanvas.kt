package com.example.ui.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import com.example.game.GameEngine
import com.example.game.GameSnapshot
import com.example.game.PlatformKind
import com.example.game.PlayerState
import com.example.game.RotationPivot
import com.example.game.RuntimeExitDoor
import com.example.game.RuntimeFakeCheckpoint
import com.example.game.RuntimePlatform
import com.example.game.RuntimeProjectile
import com.example.game.RuntimeSpike
import com.example.game.SpikeOrientation
import com.example.ui.theme.CrumbleStone
import com.example.ui.theme.DungeonSurface
import com.example.ui.theme.DungeonVoid
import com.example.ui.theme.ExitEmerald
import com.example.ui.theme.ExitEmeraldDark
import com.example.ui.theme.FakeGold
import com.example.ui.theme.FlipCyan
import com.example.ui.theme.GhostOutline
import com.example.ui.theme.RunnerAmber
import com.example.ui.theme.RunnerDarkOutline
import com.example.ui.theme.RunnerOrange
import com.example.ui.theme.SpikeCrimson
import com.example.ui.theme.SpikeGlow
import com.example.ui.theme.StoneFill
import com.example.ui.theme.StoneHighlight
import com.example.ui.theme.StoneShadow
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun GameCanvas(
    snapshot: GameSnapshot,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val worldW = GameEngine.VIEWPORT_WIDTH
        val worldH = GameEngine.VIEWPORT_HEIGHT
        val scale = min(size.width / worldW, size.height / worldH)
        val drawW = worldW * scale
        val drawH = worldH * scale
        val offsetX = (size.width - drawW) * 0.5f
        val offsetY = (size.height - drawH) * 0.5f

        // Background full-bleed dungeon atmosphere
        drawRect(
            brush = Brush.verticalGradient(
                colors = if (snapshot.controlsFlipped) {
                    listOf(Color(0xFF0A1F2B), Color(0xFF141024), DungeonVoid)
                } else {
                    listOf(Color(0xFF1C1628), DungeonSurface, DungeonVoid)
                }
            )
        )

        val shakeX = if (snapshot.screenShake > 0.1f) {
            (Random.nextFloat() * 2f - 1f) * snapshot.screenShake * scale * 0.6f
        } else 0f
        val shakeY = if (snapshot.screenShake > 0.1f) {
            (Random.nextFloat() * 2f - 1f) * snapshot.screenShake * scale * 0.6f
        } else 0f

        translate(left = offsetX + shakeX, top = offsetY + shakeY) {
            // Subtle dungeon grid (parallax)
            drawDungeonGrid(
                scale = scale,
                cameraX = snapshot.cameraX,
                viewportW = worldW,
                viewportH = worldH,
                flipped = snapshot.controlsFlipped
            )

            // Control-flip danger zones
            for (zone in snapshot.level.controlFlipZones) {
                val zx = (zone.minX - snapshot.cameraX) * scale
                val zw = (zone.maxX - zone.minX) * scale
                drawRect(
                    color = FlipCyan.copy(alpha = 0.08f),
                    topLeft = Offset(zx, 0f),
                    size = Size(zw, worldH * scale)
                )
                drawLine(
                    color = FlipCyan.copy(alpha = 0.45f),
                    start = Offset(zx, 0f),
                    end = Offset(zx, worldH * scale),
                    strokeWidth = 2f * scale
                )
                drawLine(
                    color = FlipCyan.copy(alpha = 0.45f),
                    start = Offset(zx + zw, 0f),
                    end = Offset(zx + zw, worldH * scale),
                    strokeWidth = 2f * scale
                )
            }

            // World camera transform
            translate(left = -snapshot.cameraX * scale, top = 0f) {
                // Platforms
                for (rp in snapshot.platforms) {
                    if (!rp.active) continue
                    if (rp.def.kind == PlatformKind.INVISIBLE_BONK && !rp.revealed) continue
                    drawPlatform(rp, scale)
                }

                // Fake Checkpoints
                for (fc in snapshot.fakeCheckpoints) {
                    drawFakeCheckpoint(fc, scale, snapshot.elapsedTime)
                }

                // Exit Door (with cartoon legs if running away!)
                drawExitDoor(snapshot.exitDoor, scale, snapshot.elapsedTime)

                // Spikes
                for (rs in snapshot.spikes) {
                    if (!rs.active || rs.extension <= 0.02f) continue
                    drawSpike(rs, scale)
                }

                // Sniper Projectiles
                for (proj in snapshot.projectiles) {
                    if (!proj.active || !proj.fired) continue
                    drawProjectile(proj, scale)
                }

                // Chasing Saw Wall
                snapshot.sawX?.let { sx ->
                    drawChasingSaw(sx, snapshot.sawAngle, worldH, scale)
                }

                // Player Runner
                if (snapshot.player.alive) {
                    drawPlayer(snapshot.player, scale, snapshot.controlsFlipped)
                }

                // Particles
                for (p in snapshot.particles) {
                    val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
                    drawRect(
                        color = p.color.copy(alpha = alpha),
                        topLeft = Offset(p.x * scale, p.y * scale),
                        size = Size(p.size * scale, p.size * scale)
                    )
                }
            }

            // Crisp stage frame border
            drawRect(
                color = if (snapshot.controlsFlipped) FlipCyan.copy(alpha = 0.55f) else Color(0xFF342D47),
                topLeft = Offset.Zero,
                size = Size(drawW, drawH),
                style = Stroke(width = 2.5f)
            )
        }
    }
}

private fun DrawScope.drawDungeonGrid(
    scale: Float,
    cameraX: Float,
    viewportW: Float,
    viewportH: Float,
    flipped: Boolean
) {
    val gridColor = if (flipped) FlipCyan.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.04f)
    val tile = 40f
    val parallaxX = (cameraX * 0.35f) % tile
    var x = -parallaxX
    while (x <= viewportW) {
        drawLine(
            color = gridColor,
            start = Offset(x * scale, 0f),
            end = Offset(x * scale, viewportH * scale),
            strokeWidth = 1f
        )
        x += tile
    }
    var y = 0f
    while (y <= viewportH) {
        drawLine(
            color = gridColor,
            start = Offset(0f, y * scale),
            end = Offset(viewportW * scale, y * scale),
            strokeWidth = 1f
        )
        y += tile
    }
}

private fun DrawScope.drawPlatform(rp: RuntimePlatform, scale: Float) {
    val px = (rp.x + rp.shakeOffset) * scale
    val py = rp.y * scale
    val pw = rp.def.w * scale
    val ph = rp.def.h * scale

    when (rp.def.kind) {
        PlatformKind.FAKE_SOLID -> {
            val alpha = if (rp.triggered) 0.25f else 0.94f
            drawRoundRect(
                color = StoneFill.copy(alpha = alpha),
                topLeft = Offset(px, py),
                size = Size(pw, ph),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )
            drawRect(
                color = StoneHighlight.copy(alpha = alpha),
                topLeft = Offset(px, py),
                size = Size(pw, 5f * scale)
            )
            if (rp.triggered) {
                drawRoundRect(
                    color = GhostOutline.copy(alpha = 0.7f),
                    topLeft = Offset(px, py),
                    size = Size(pw, ph),
                    cornerRadius = CornerRadius(4f * scale, 4f * scale),
                    style = Stroke(width = 1.5f * scale)
                )
            }
        }

        PlatformKind.BOUNCE_TROLL -> {
            drawRoundRect(
                color = Color(0xFF2B253A),
                topLeft = Offset(px, py + 6f * scale),
                size = Size(pw, ph - 6f * scale),
                cornerRadius = CornerRadius(3f * scale, 3f * scale)
            )
            drawRoundRect(
                color = FakeGold,
                topLeft = Offset(px - 2f * scale, py),
                size = Size(pw + 4f * scale, 8f * scale),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )
            // Zigzag spring lines
            drawLine(
                color = RunnerOrange,
                start = Offset(px + pw * 0.25f, py + 8f * scale),
                end = Offset(px + pw * 0.75f, py + ph - 2f * scale),
                strokeWidth = 2.5f * scale
            )
            drawLine(
                color = RunnerOrange,
                start = Offset(px + pw * 0.75f, py + 8f * scale),
                end = Offset(px + pw * 0.25f, py + ph - 2f * scale),
                strokeWidth = 2.5f * scale
            )
        }

        PlatformKind.INVISIBLE_BONK -> {
            // Revealed purple/crimson troll block!
            drawRoundRect(
                color = Color(0xFF7B2CBF),
                topLeft = Offset(px, py),
                size = Size(pw, ph),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )
            drawRoundRect(
                color = Color(0xFFFFD43B),
                topLeft = Offset(px, py),
                size = Size(pw, ph),
                cornerRadius = CornerRadius(4f * scale, 4f * scale),
                style = Stroke(width = 2.2f * scale)
            )
            // Cheeky "!" mark
            drawRect(
                color = FakeGold,
                topLeft = Offset(px + pw * 0.44f, py + ph * 0.18f),
                size = Size(pw * 0.12f, ph * 0.42f)
            )
            drawCircle(
                color = FakeGold,
                radius = pw * 0.08f,
                center = Offset(px + pw * 0.5f, py + ph * 0.78f)
            )
        }

        PlatformKind.CRUMBLE -> {
            val fill = if (rp.triggered) SpikeCrimson.copy(alpha = 0.85f) else CrumbleStone
            drawRoundRect(
                color = fill,
                topLeft = Offset(px, py),
                size = Size(pw, ph),
                cornerRadius = CornerRadius(3f * scale, 3f * scale)
            )
            drawRect(
                color = StoneHighlight.copy(alpha = 0.8f),
                topLeft = Offset(px, py),
                size = Size(pw, 4f * scale)
            )
            // Crack lines signaling fragile stone
            drawLine(
                color = DungeonVoid,
                start = Offset(px + pw * 0.3f, py + 2f * scale),
                end = Offset(px + pw * 0.42f, py + ph * 0.75f),
                strokeWidth = 2f * scale
            )
            drawLine(
                color = DungeonVoid,
                start = Offset(px + pw * 0.68f, py + 3f * scale),
                end = Offset(px + pw * 0.58f, py + ph * 0.8f),
                strokeWidth = 2f * scale
            )
        }

        PlatformKind.VANISH_ON_TOUCH -> {
            // Appears 100% identical to safe SOLID stone until touched, then flashes & vanishes!
            val alpha = rp.vanishAlpha.coerceIn(0f, 1f)
            val fill = if (rp.triggered) Color.White.copy(alpha = alpha) else StoneFill
            val topLip = if (rp.triggered) SpikeGlow.copy(alpha = alpha) else StoneHighlight
            val bottomShadow = StoneShadow.copy(alpha = alpha)

            drawRoundRect(
                color = fill,
                topLeft = Offset(px, py),
                size = Size(pw, ph),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )
            drawRect(
                color = topLip,
                topLeft = Offset(px, py),
                size = Size(pw, 5f * scale)
            )
            drawRect(
                color = bottomShadow,
                topLeft = Offset(px, py + ph - 6f * scale),
                size = Size(pw, 6f * scale)
            )
            drawRoundRect(
                color = RunnerDarkOutline.copy(alpha = alpha),
                topLeft = Offset(px, py),
                size = Size(pw, ph),
                cornerRadius = CornerRadius(4f * scale, 4f * scale),
                style = Stroke(width = 1.6f * scale)
            )
        }

        PlatformKind.ROTATE_ON_TOUCH -> {
            // Appears 100% identical to safe SOLID stone until touched, then swings open around pivot!
            val pivot = when (rp.def.rotatePivot) {
                RotationPivot.LEFT_EDGE -> Offset(px + 6f * scale, py + ph * 0.5f)
                RotationPivot.RIGHT_EDGE -> Offset(px + pw - 6f * scale, py + ph * 0.5f)
                RotationPivot.CENTER -> Offset(px + pw * 0.5f, py + ph * 0.5f)
            }
            rotate(degrees = rp.rotationDeg, pivot = pivot) {
                val baseColor = if (rp.triggered) Color(0xFFE04F26) else StoneFill
                drawRoundRect(
                    color = baseColor,
                    topLeft = Offset(px, py),
                    size = Size(pw, ph),
                    cornerRadius = CornerRadius(4f * scale, 4f * scale)
                )
                drawRect(
                    color = StoneHighlight,
                    topLeft = Offset(px, py),
                    size = Size(pw, 5f * scale)
                )
                drawRect(
                    color = StoneShadow,
                    topLeft = Offset(px, py + ph - 6f * scale),
                    size = Size(pw, 6f * scale)
                )
                drawRoundRect(
                    color = RunnerDarkOutline,
                    topLeft = Offset(px, py),
                    size = Size(pw, ph),
                    cornerRadius = CornerRadius(4f * scale, 4f * scale),
                    style = Stroke(width = 1.6f * scale)
                )
            }
            // Reveal glowing mechanical hinge pin once rotation starts!
            if (rp.triggered) {
                drawCircle(
                    color = SpikeCrimson,
                    radius = 4.2f * scale,
                    center = pivot
                )
                drawCircle(
                    color = FakeGold,
                    radius = 2f * scale,
                    center = pivot
                )
            }
        }

        else -> {
            // SOLID / DROP_TRAP / MOVING_SNAP look identical until triggered!
            val baseColor = if (rp.triggered && rp.def.kind == PlatformKind.DROP_TRAP) {
                Color(0xFFE04F26)
            } else StoneFill

            drawRoundRect(
                color = baseColor,
                topLeft = Offset(px, py),
                size = Size(pw, ph),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )
            // Top warm highlight lip
            drawRect(
                color = StoneHighlight,
                topLeft = Offset(px, py),
                size = Size(pw, 5f * scale)
            )
            // Bottom/side shadow
            drawRect(
                color = StoneShadow,
                topLeft = Offset(px, py + ph - 6f * scale),
                size = Size(pw, 6f * scale)
            )
            drawRoundRect(
                color = RunnerDarkOutline,
                topLeft = Offset(px, py),
                size = Size(pw, ph),
                cornerRadius = CornerRadius(4f * scale, 4f * scale),
                style = Stroke(width = 1.6f * scale)
            )
        }
    }
}

private fun DrawScope.drawSpike(rs: RuntimeSpike, scale: Float) {
    val def = rs.def
    val count = (def.w / 14f).toInt().coerceAtLeast(1)
    val singleW = (def.w / count) * scale
    val activeH = def.h * rs.extension * scale
    val baseX = rs.x * scale
    val baseY = rs.y * scale
    val fullH = def.h * scale

    for (i in 0 until count) {
        val sx = baseX + i * singleW
        val path = Path()
        when (def.orientation) {
            SpikeOrientation.UP -> {
                val bottom = baseY + fullH
                val top = bottom - activeH
                path.moveTo(sx, bottom)
                path.lineTo(sx + singleW * 0.5f, top)
                path.lineTo(sx + singleW, bottom)
                path.close()
            }
            SpikeOrientation.DOWN -> {
                path.moveTo(sx, baseY)
                path.lineTo(sx + singleW * 0.5f, baseY + activeH)
                path.lineTo(sx + singleW, baseY)
                path.close()
            }
            SpikeOrientation.LEFT -> {
                path.moveTo(baseX + def.w * scale, baseY)
                path.lineTo(baseX, baseY + fullH * 0.5f)
                path.lineTo(baseX + def.w * scale, baseY + fullH)
                path.close()
            }
            SpikeOrientation.RIGHT -> {
                path.moveTo(baseX, baseY)
                path.lineTo(baseX + def.w * scale, baseY + fullH * 0.5f)
                path.lineTo(baseX, baseY + fullH)
                path.close()
            }
        }
        drawPath(path = path, color = SpikeCrimson)
        drawPath(path = path, color = SpikeGlow, style = Stroke(width = 1.3f * scale))
    }
}

private fun DrawScope.drawProjectile(proj: RuntimeProjectile, scale: Float) {
    val px = proj.x * scale
    val py = proj.y * scale
    val pw = proj.def.w * scale
    val ph = proj.def.h * scale

    // Glowing trail
    drawRect(
        color = SpikeCrimson.copy(alpha = 0.35f),
        topLeft = Offset(px + pw * 0.5f, py + ph * 0.25f),
        size = Size(pw * 0.9f, ph * 0.5f)
    )
    // Sharp flying spearhead pointing left
    val spear = Path().apply {
        moveTo(px, py + ph * 0.5f)
        lineTo(px + pw, py)
        lineTo(px + pw * 0.78f, py + ph * 0.5f)
        lineTo(px + pw, py + ph)
        close()
    }
    drawPath(spear, color = SpikeCrimson)
    drawPath(spear, color = FakeGold, style = Stroke(width = 1.4f * scale))
}

private fun DrawScope.drawFakeCheckpoint(
    fc: RuntimeFakeCheckpoint,
    scale: Float,
    time: Float
) {
    val fx = fc.def.x * scale
    val fy = fc.def.y * scale
    val fw = fc.def.w * scale
    val fh = fc.def.h * scale

    // Flag pole
    drawRect(
        color = Color(0xFFEAE2FF),
        topLeft = Offset(fx + 3f * scale, fy),
        size = Size(4f * scale, fh)
    )
    if (!fc.exploded) {
        val wave = sin(time * 7f) * 2.5f * scale
        val flag = Path().apply {
            moveTo(fx + 7f * scale, fy + 2f * scale)
            lineTo(fx + fw + 6f * scale, fy + 9f * scale + wave)
            lineTo(fx + 7f * scale, fy + 18f * scale)
            close()
        }
        drawPath(flag, color = ExitEmerald)
        drawPath(flag, color = Color.White, style = Stroke(width = 1.2f * scale))
    } else {
        // Exploded red skull spikes!
        drawCircle(
            color = SpikeCrimson.copy(alpha = 0.75f),
            radius = 16f * scale,
            center = Offset(fx + fw * 0.5f, fy + fh * 0.4f)
        )
    }
}

private fun DrawScope.drawExitDoor(
    door: RuntimeExitDoor,
    scale: Float,
    time: Float
) {
    val dx = door.x * scale
    val dy = door.y * scale
    val dw = door.w * scale
    val dh = door.h * scale
    val pulse = (sin(time * 5f) * 0.14f + 0.86f)

    // Outer emerald aura
    drawRoundRect(
        color = ExitEmerald.copy(alpha = 0.22f * pulse),
        topLeft = Offset(dx - 5f * scale, dy - 5f * scale),
        size = Size(dw + 10f * scale, dh + 10f * scale),
        cornerRadius = CornerRadius(8f * scale, 8f * scale)
    )

    // Cartoon running legs when the door flees!
    if (door.isRunning) {
        val swing = sin(door.legPhase) * 9f * scale
        drawLine(
            color = ExitEmerald,
            start = Offset(dx + dw * 0.3f, dy + dh),
            end = Offset(dx + dw * 0.3f + swing, dy + dh + 11f * scale),
            strokeWidth = 3.5f * scale
        )
        drawLine(
            color = ExitEmerald,
            start = Offset(dx + dw * 0.7f, dy + dh),
            end = Offset(dx + dw * 0.7f - swing, dy + dh + 11f * scale),
            strokeWidth = 3.5f * scale
        )
    }

    // Door frame
    drawRoundRect(
        color = ExitEmeraldDark,
        topLeft = Offset(dx, dy),
        size = Size(dw, dh),
        cornerRadius = CornerRadius(6f * scale, 6f * scale)
    )
    // Inner glowing door
    drawRoundRect(
        color = ExitEmerald,
        topLeft = Offset(dx + 3f * scale, dy + 3f * scale),
        size = Size(dw - 6f * scale, dh - 4f * scale),
        cornerRadius = CornerRadius(4f * scale, 4f * scale)
    )
    // Door inner panel
    drawRoundRect(
        color = ExitEmeraldDark.copy(alpha = 0.45f),
        topLeft = Offset(dx + 7f * scale, dy + 8f * scale),
        size = Size(dw - 14f * scale, dh * 0.36f),
        cornerRadius = CornerRadius(2f * scale, 2f * scale)
    )
    // Cheeky eyes if running away!
    if (door.isRunning) {
        drawCircle(Color.Black, radius = 2.6f * scale, center = Offset(dx + dw * 0.35f, dy + dh * 0.34f))
        drawCircle(Color.Black, radius = 2.6f * scale, center = Offset(dx + dw * 0.65f, dy + dh * 0.34f))
    }
    // Golden doorknob
    drawCircle(
        color = FakeGold,
        radius = 3.2f * scale,
        center = Offset(dx + dw - 8f * scale, dy + dh * 0.56f)
    )
}

private fun DrawScope.drawChasingSaw(
    sawX: Float,
    angle: Float,
    worldH: Float,
    scale: Float
) {
    // Crimson death wall behind the saw blades
    val wallRight = (sawX + 12f) * scale
    if (wallRight > -200f) {
        drawRect(
            brush = Brush.horizontalGradient(
                colors = listOf(Color(0xFF420614), SpikeCrimson.copy(alpha = 0.85f)),
                startX = wallRight - 90f * scale,
                endX = wallRight
            ),
            topLeft = Offset(wallRight - 90f * scale, 0f),
            size = Size(90f * scale, worldH * scale)
        )
    }

    // 4 giant spinning saw wheels stacked vertically
    val centers = listOf(52f, 138f, 224f, 310f)
    val radius = 38f * scale
    for (cy in centers) {
        val center = Offset((sawX + 8f) * scale, cy * scale)
        rotate(degrees = angle, pivot = center) {
            val teeth = 10
            val path = Path()
            for (i in 0 until teeth * 2) {
                val r = if (i % 2 == 0) radius else radius * 0.68f
                val a = (i * PI / teeth).toFloat()
                val px = center.x + cos(a) * r
                val py = center.y + sin(a) * r
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            drawPath(path, color = Color(0xFFD8D0E8))
            drawPath(path, color = SpikeCrimson, style = Stroke(width = 2.5f * scale))
            drawCircle(color = SpikeCrimson, radius = radius * 0.28f, center = center)
        }
    }
}

private fun DrawScope.drawPlayer(
    player: PlayerState,
    scale: Float,
    flipped: Boolean
) {
    val px = player.x * scale
    val py = player.y * scale
    val pw = player.w * scale
    val ph = player.h * scale

    // Little animated running feet
    val legSwing = sin(player.runCycle) * 4.5f * scale
    drawLine(
        color = RunnerDarkOutline,
        start = Offset(px + pw * 0.3f, py + ph - 2f * scale),
        end = Offset(px + pw * 0.3f + legSwing, py + ph + 3f * scale),
        strokeWidth = 3f * scale
    )
    drawLine(
        color = RunnerDarkOutline,
        start = Offset(px + pw * 0.7f, py + ph - 2f * scale),
        end = Offset(px + pw * 0.7f - legSwing, py + ph + 3f * scale),
        strokeWidth = 3f * scale
    )

    // Cube body with crisp neo-arcade bevel
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = if (flipped) listOf(FlipCyan, RunnerOrange) else listOf(RunnerAmber, RunnerOrange),
            startY = py,
            endY = py + ph
        ),
        topLeft = Offset(px, py),
        size = Size(pw, ph),
        cornerRadius = CornerRadius(5f * scale, 5f * scale)
    )
    drawRoundRect(
        color = RunnerDarkOutline,
        topLeft = Offset(px, py),
        size = Size(pw, ph),
        cornerRadius = CornerRadius(5f * scale, 5f * scale),
        style = Stroke(width = 2.2f * scale)
    )

    // Expressive eyes! Wide shocked eyes when a trap triggers!
    val eyeShift = if (player.facingRight) 2.5f * scale else -2.5f * scale
    val leftEyeCenter = Offset(px + pw * 0.35f + eyeShift, py + ph * 0.42f)
    val rightEyeCenter = Offset(px + pw * 0.68f + eyeShift, py + ph * 0.42f)
    val eyeRadius = if (player.shockedTimer > 0f) 4.2f * scale else 3.2f * scale

    drawCircle(color = Color.White, radius = eyeRadius, center = leftEyeCenter)
    drawCircle(color = Color.White, radius = eyeRadius, center = rightEyeCenter)

    val pupilShift = if (player.facingRight) 1.1f * scale else -1.1f * scale
    val pupilR = if (player.shockedTimer > 0f) 1.4f * scale else 1.8f * scale
    drawCircle(color = DungeonVoid, radius = pupilR, center = leftEyeCenter + Offset(pupilShift, 0f))
    drawCircle(color = DungeonVoid, radius = pupilR, center = rightEyeCenter + Offset(pupilShift, 0f))

    // Mouth: shocked "O" when ambushed, cheeky smirk otherwise
    if (player.shockedTimer > 0f) {
        drawCircle(
            color = DungeonVoid,
            radius = 2.6f * scale,
            center = Offset(px + pw * 0.52f + eyeShift * 0.6f, py + ph * 0.74f)
        )
    } else {
        drawLine(
            color = DungeonVoid,
            start = Offset(px + pw * 0.38f + eyeShift * 0.5f, py + ph * 0.73f),
            end = Offset(px + pw * 0.66f + eyeShift * 0.5f, py + ph * 0.70f),
            strokeWidth = 2f * scale
        )
    }
}
