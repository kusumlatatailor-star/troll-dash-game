package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neo-Brutalist Dark Arcade Palette for Troll Dash
val DungeonVoid = Color(0xFF100E16)
val DungeonSurface = Color(0xFF1A1724)
val DungeonCard = Color(0xFF231F30)
val DungeonElevated = Color(0xFF2D283D)
val DungeonBorder = Color(0xFF3E3754)

val RunnerOrange = Color(0xFFFF7A1A)
val RunnerAmber = Color(0xFFFFB020)
val RunnerDarkOutline = Color(0xFF2B1206)

val SpikeCrimson = Color(0xFFFF2E54)
val SpikeGlow = Color(0xFFFF6682)
val RageRedContainer = Color(0xFF42111D)

val ExitEmerald = Color(0xFF2EE578)
val ExitEmeraldDark = Color(0xFF0E4726)
val FlipCyan = Color(0xFF29D4FF)
val FakeGold = Color(0xFFFFD43B)

val TextPrimary = Color(0xFFF7F4FF)
val TextSecondary = Color(0xFFB7AECB)
val TextMuted = Color(0xFF7B7291)

// Game world stone colors
val StoneFill = Color(0xFFD96B27)
val StoneHighlight = Color(0xFFFFA552)
val StoneShadow = Color(0xFF7A320C)
val CrumbleStone = Color(0xFFC4523A)
val GhostOutline = Color(0xFF8C7DB5)
