package com.example.ui.game

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Dangerous
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.DungeonCard
import com.example.ui.theme.DungeonVoid
import com.example.ui.theme.ExitEmerald
import com.example.ui.theme.FakeGold
import com.example.ui.theme.RunnerOrange
import com.example.ui.theme.SpikeCrimson
import com.example.ui.theme.SpikeGlow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.random.Random

private val DODGE_TAUNTS = listOf(
    "PAKAD KE DIKHA! 😜",
    "IDHAR NAHI BHAI! 🏃",
    "MESSAGE BHI BHAAG GAYA! 😂",
    "UNGLI TEZ CHALAO! ⚡",
    "RESPAWN BHI TROLL KAR RAHA! 😈",
    "ITNA SLOW?! HAHA! 💀"
)

/**
 * Signature Troll Dash Death Overlay:
 * - On 1st death (levelDeaths == 1): Clean centered death message + stationary Respawn button.
 * - On 2nd+ death (levelDeaths >= 2): BOTH the Death Message card AND the Respawn button
 *   flee away from mouse hover, finger proximity, or tap attempts!
 *   After 2..4 hilarious dodges, the Respawn button gets "tired" so the player can always respawn.
 */
@Composable
fun RunawayDeathOverlay(
    levelDeaths: Int,
    deathGeneration: Int,
    deathMessage: String,
    hapticsEnabled: Boolean,
    onButtonDodged: () -> Unit,
    onRespawn: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isTrollMode = levelDeaths >= 2
    val initialDodges = if (isTrollMode) {
        (2 + (levelDeaths - 2)).coerceIn(2, 4)
    } else 0

    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(DungeonVoid.copy(alpha = 0.72f))
    ) {
        val boxW = with(density) { maxWidth.toPx() }
        val boxH = with(density) { maxHeight.toPx() }

        val cardW = with(density) { 264.dp.toPx() }.coerceAtMost(boxW * 0.84f)
        val cardH = with(density) { 112.dp.toPx() }
        val btnW = with(density) { 188.dp.toPx() }.coerceAtMost(boxW * 0.68f)
        val btnH = with(density) { 56.dp.toPx() }
        val pad = with(density) { 14.dp.toPx() }

        val centerCard = Offset(
            x = ((boxW - cardW) * 0.5f).coerceAtLeast(pad),
            y = ((boxH * 0.30f) - cardH * 0.5f).coerceIn(pad, (boxH - cardH - pad).coerceAtLeast(pad))
        )
        val centerBtn = Offset(
            x = ((boxW - btnW) * 0.5f).coerceAtLeast(pad),
            y = ((boxH * 0.68f) - btnH * 0.5f).coerceIn(pad, (boxH - btnH - pad).coerceAtLeast(pad))
        )

        var dodgesLeft by remember(deathGeneration) { mutableIntStateOf(initialDodges) }
        var cardTarget by remember(deathGeneration, boxW, boxH) { mutableStateOf(centerCard) }
        var btnTarget by remember(deathGeneration, boxW, boxH) { mutableStateOf(centerBtn) }
        var dodgeBannerText by remember(deathGeneration) { mutableStateOf(deathMessage) }
        var lastDodgeTimeMs by remember(deathGeneration) { mutableStateOf(0L) }

        LaunchedEffect(deathGeneration, boxW, boxH) {
            dodgesLeft = initialDodges
            cardTarget = centerCard
            btnTarget = centerBtn
            dodgeBannerText = deathMessage
        }

        val animatedCardPos by animateOffsetAsState(
            targetValue = cardTarget,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium
            ),
            label = "death_card_escape"
        )
        val animatedBtnPos by animateOffsetAsState(
            targetValue = btnTarget,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "respawn_btn_escape"
        )

        fun pickEscapeSpot(
            avoidPoint: Offset,
            itemW: Float,
            itemH: Float,
            otherTopLeft: Offset,
            otherW: Float,
            otherH: Float
        ): Offset {
            val minX = pad
            val maxX = (boxW - itemW - pad).coerceAtLeast(minX)
            val minY = pad
            val maxY = (boxH - itemH - pad).coerceAtLeast(minY)

            var best = Offset(minX, minY)
            var bestScore = -1f
            repeat(18) {
                val cx = minX + Random.nextFloat() * (maxX - minX)
                val cy = minY + Random.nextFloat() * (maxY - minY)
                val distFromPointer = hypot(
                    (cx + itemW * 0.5f) - avoidPoint.x,
                    (cy + itemH * 0.5f) - avoidPoint.y
                )
                val distFromOther = hypot(
                    (cx + itemW * 0.5f) - (otherTopLeft.x + otherW * 0.5f),
                    (cy + itemH * 0.5f) - (otherTopLeft.y + otherH * 0.5f)
                )
                val overlapPenalty = if (distFromOther < (itemH + otherH) * 0.65f) 400f else 0f
                val score = distFromPointer + distFromOther * 0.35f - overlapPenalty
                if (score > bestScore) {
                    bestScore = score
                    best = Offset(cx, cy)
                }
            }
            return best
        }

        fun fleeCard(fromPointer: Offset) {
            cardTarget = pickEscapeSpot(
                avoidPoint = fromPointer,
                itemW = cardW,
                itemH = cardH,
                otherTopLeft = btnTarget,
                otherW = btnW,
                otherH = btnH
            )
            dodgeBannerText = DODGE_TAUNTS.random()
            onButtonDodged()
            if (hapticsEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
        }

        fun fleeButton(fromPointer: Offset) {
            if (dodgesLeft <= 0) return
            dodgesLeft -= 1
            btnTarget = pickEscapeSpot(
                avoidPoint = fromPointer,
                itemW = btnW,
                itemH = btnH,
                otherTopLeft = cardTarget,
                otherW = cardW,
                otherH = cardH
            )
            // Also make the death message jump playfully when the respawn button bolts!
            cardTarget = pickEscapeSpot(
                avoidPoint = fromPointer,
                itemW = cardW,
                itemH = cardH,
                otherTopLeft = btnTarget,
                otherW = btnW,
                otherH = btnH
            )
            dodgeBannerText = DODGE_TAUNTS.random()
            onButtonDodged()
            if (hapticsEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
        }

        // Full-overlay pointer watcher: catches BOTH mouse hover/move AND finger drags/taps!
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(deathGeneration, isTrollMode, boxW, boxH) {
                    if (!isTrollMode) return@pointerInput
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            if (event.type == PointerEventType.Move || event.type == PointerEventType.Press) {
                                val pointer = event.changes.firstOrNull()?.position ?: continue
                                val now = System.currentTimeMillis()
                                if (now - lastDodgeTimeMs < 240L) continue

                                // Check proximity to Death Message card
                                val cardCenter = Offset(cardTarget.x + cardW * 0.5f, cardTarget.y + cardH * 0.5f)
                                val cardHitX = pointer.x in (cardTarget.x - 28f)..(cardTarget.x + cardW + 28f)
                                val cardHitY = pointer.y in (cardTarget.y - 24f)..(cardTarget.y + cardH + 24f)

                                // Check proximity to Respawn Button
                                val btnHitX = pointer.x in (btnTarget.x - 32f)..(btnTarget.x + btnW + 32f)
                                val btnHitY = pointer.y in (btnTarget.y - 26f)..(btnTarget.y + btnH + 26f)

                                if (btnHitX && btnHitY && dodgesLeft > 0) {
                                    lastDodgeTimeMs = now
                                    // Consume press so it dodges cleanly instead of clicking early!
                                    if (event.type == PointerEventType.Press) {
                                        event.changes.forEach { it.consume() }
                                    }
                                    fleeButton(pointer)
                                } else if (cardHitX && cardHitY && hypot(pointer.x - cardCenter.x, pointer.y - cardCenter.y) < cardW * 0.72f) {
                                    lastDodgeTimeMs = now
                                    fleeCard(pointer)
                                }
                            }
                        }
                    }
                }
        ) {
            // 1. DEATH MESSAGE CARD (Stationary on Death #1, Runs Away on Death #2+!)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = DungeonCard,
                border = BorderStroke(2.dp, if (isTrollMode) SpikeCrimson else RunnerOrange),
                shadowElevation = 10.dp,
                modifier = Modifier
                    .offset {
                        IntOffset(
                            animatedCardPos.x.roundToInt(),
                            animatedCardPos.y.roundToInt()
                        )
                    }
                    .widthIn(min = 220.dp, max = 264.dp)
                    .clickable(enabled = isTrollMode) {
                        val center = Offset(cardTarget.x + cardW * 0.5f, cardTarget.y + cardH * 0.5f)
                        fleeCard(center)
                    }
                    .testTag("death_message_card")
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Dangerous,
                            contentDescription = null,
                            tint = SpikeCrimson,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (isTrollMode) "DEATH #$levelDeaths • TROLL MODE" else "DEATH #1",
                            style = MaterialTheme.typography.labelMedium,
                            color = SpikeGlow
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = dodgeBannerText,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        textAlign = TextAlign.Center
                    )
                    if (isTrollMode) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (dodgesLeft > 0) {
                                stringResource(R.string.catch_respawn_hint, dodgesLeft)
                            } else {
                                stringResource(R.string.respawn_surrender_hint)
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (dodgesLeft > 0) FakeGold else ExitEmerald,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // 2. RESPAWN BUTTON (Stationary on Death #1, Runs Away on Death #2+!)
            val canCatchNow = !isTrollMode || dodgesLeft <= 0
            Button(
                onClick = {
                    if (canCatchNow) {
                        onRespawn()
                    } else {
                        val btnCenter = Offset(btnTarget.x + btnW * 0.5f, btnTarget.y + btnH * 0.5f)
                        fleeButton(btnCenter)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = when {
                        !isTrollMode -> RunnerOrange
                        dodgesLeft > 0 -> SpikeCrimson
                        else -> ExitEmerald
                    },
                    contentColor = if (!isTrollMode || dodgesLeft <= 0) DungeonVoid else Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .offset {
                        IntOffset(
                            animatedBtnPos.x.roundToInt(),
                            animatedBtnPos.y.roundToInt()
                        )
                    }
                    .width(188.dp)
                    .height(54.dp)
                    .testTag("respawn_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isTrollMode && dodgesLeft > 0) "RESPAWN 😜" else stringResource(R.string.respawn_cta),
                    style = MaterialTheme.typography.labelLarge
                )
            }

            // Subtle corner badge on Death 2+ so player realizes why it's running away
            if (isTrollMode) {
                Text(
                    text = "2+ DEATHS: BUTTON & MESSAGE BHAAGENGE!",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary.copy(alpha = 0.85f),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp)
                )
            }
        }
    }
}
