package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.DungeonBorder
import com.example.ui.theme.DungeonCard
import com.example.ui.theme.DungeonVoid
import com.example.ui.theme.ExitEmerald
import com.example.ui.theme.FakeGold
import com.example.ui.theme.RunnerOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GrandVictoryScreen(
    totalDeaths: Int,
    onReplayAll: () -> Unit,
    onBackToMenu: () -> Unit
) {
    BackHandler(onBack = onBackToMenu)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF14291E), DungeonVoid, Color(0xFF22131E))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = DungeonCard,
            shape = RoundedCornerShape(26.dp),
            border = BorderStroke(2.5.dp, FakeGold),
            modifier = Modifier
                .padding(24.dp)
                .widthIn(max = 460.dp)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.EmojiEvents,
                    contentDescription = null,
                    tint = FakeGold,
                    modifier = Modifier.size(64.dp)
                )
                Text(
                    text = stringResource(R.string.all_cleared_title),
                    style = MaterialTheme.typography.displaySmall,
                    color = ExitEmerald,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = stringResource(R.string.all_cleared_subtitle),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Surface(
                    color = DungeonVoid,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, DungeonBorder)
                ) {
                    Text(
                        text = "TOTAL RAGE DEATHS: $totalDeaths 💀",
                        style = MaterialTheme.typography.labelLarge,
                        color = RunnerOrange,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
                Text(
                    text = "Asli legend ho tum — phone abhi bhi sahi salamat hai!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onReplayAll,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RunnerOrange,
                        contentColor = DungeonVoid
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("victory_replay_button")
                ) {
                    Text(
                        text = "PLAY LEVEL 1 AGAIN",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                OutlinedButton(
                    onClick = onBackToMenu,
                    border = BorderStroke(1.5.dp, DungeonBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("victory_menu_button")
                ) {
                    Text(
                        text = stringResource(R.string.back_to_menu),
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}
