package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Whatshot
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.PlayerProgress
import com.example.game.LevelCatalog
import com.example.game.LevelDefinition
import com.example.ui.theme.DungeonBorder
import com.example.ui.theme.DungeonCard
import com.example.ui.theme.DungeonSurface
import com.example.ui.theme.DungeonVoid
import com.example.ui.theme.ExitEmerald
import com.example.ui.theme.FakeGold
import com.example.ui.theme.RunnerOrange
import com.example.ui.theme.SpikeCrimson
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LevelSelectScreen(
    progress: PlayerProgress,
    onSelectLevel: (Int) -> Unit,
    onUnlockAll: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DungeonVoid)
            .statusBarsPadding()
    ) {
        // Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DungeonSurface)
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("levels_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = stringResource(R.string.navigate_back_desc),
                    tint = TextPrimary
                )
            }
            Text(
                text = stringResource(R.string.select_level_title),
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                modifier = Modifier.weight(1f)
            )
            if (progress.unlockedLevel < 10) {
                TextButton(
                    onClick = onUnlockAll,
                    modifier = Modifier.testTag("unlock_all_levels_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LockOpen,
                        contentDescription = null,
                        tint = FakeGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.size(4.dp))
                    Text(
                        text = stringResource(R.string.unlock_all_cta),
                        style = MaterialTheme.typography.labelSmall,
                        color = FakeGold
                    )
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
        ) {
            items(LevelCatalog.levels, key = { it.number }) { level ->
                val unlocked = level.number <= progress.unlockedLevel
                val cleared = level.number in progress.completedLevels
                val bestDeaths = progress.bestDeathsByLevel[level.number]

                LevelGridCard(
                    level = level,
                    unlocked = unlocked,
                    cleared = cleared,
                    bestDeaths = bestDeaths,
                    onClick = { if (unlocked) onSelectLevel(level.number) }
                )
            }
        }
    }
}

@Composable
private fun LevelGridCard(
    level: LevelDefinition,
    unlocked: Boolean,
    cleared: Boolean,
    bestDeaths: Int?,
    onClick: () -> Unit
) {
    val accent = Color(level.accentColorHex)
    val borderColor = when {
        cleared -> ExitEmerald
        unlocked -> accent
        else -> DungeonBorder
    }

    Surface(
        onClick = onClick,
        enabled = unlocked,
        color = if (unlocked) DungeonCard else DungeonSurface.copy(alpha = 0.7f),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(if (unlocked) 2.dp else 1.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("level_card_${level.number}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = if (unlocked) accent else DungeonBorder,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "LVL ${level.number.toString().padStart(2, '0')}",
                        style = MaterialTheme.typography.labelMedium,
                        color = DungeonVoid,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                when {
                    cleared -> Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = "Cleared",
                        tint = ExitEmerald,
                        modifier = Modifier.size(20.dp)
                    )
                    !unlocked -> Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "Locked",
                        tint = TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Text(
                text = level.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (unlocked) TextPrimary else TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = level.subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = if (unlocked) TextSecondary else TextMuted,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.height(36.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Difficulty flames
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    repeat(5) { idx ->
                        Icon(
                            imageVector = Icons.Rounded.Whatshot,
                            contentDescription = null,
                            tint = if (idx < level.difficultySkulls) {
                                if (unlocked) SpikeCrimson else TextMuted
                            } else DungeonBorder,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                if (bestDeaths != null) {
                    Text(
                        text = "Best: ${bestDeaths}💀",
                        style = MaterialTheme.typography.labelSmall,
                        color = RunnerOrange
                    )
                } else if (!unlocked) {
                    Box(modifier = Modifier.size(1.dp))
                }
            }
        }
    }
}
