package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val TrollDashColorScheme = darkColorScheme(
    primary = RunnerOrange,
    onPrimary = DungeonVoid,
    primaryContainer = DungeonElevated,
    onPrimaryContainer = RunnerAmber,
    secondary = ExitEmerald,
    onSecondary = DungeonVoid,
    secondaryContainer = ExitEmeraldDark,
    onSecondaryContainer = ExitEmerald,
    tertiary = FlipCyan,
    onTertiary = DungeonVoid,
    error = SpikeCrimson,
    onError = TextPrimary,
    errorContainer = RageRedContainer,
    onErrorContainer = SpikeGlow,
    background = DungeonVoid,
    onBackground = TextPrimary,
    surface = DungeonSurface,
    onSurface = TextPrimary,
    surfaceVariant = DungeonCard,
    onSurfaceVariant = TextSecondary,
    outline = DungeonBorder,
    outlineVariant = DungeonElevated
)

private val TrollDashShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun TrollDashTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TrollDashColorScheme,
        typography = TrollDashTypography,
        shapes = TrollDashShapes,
        content = content
    )
}
