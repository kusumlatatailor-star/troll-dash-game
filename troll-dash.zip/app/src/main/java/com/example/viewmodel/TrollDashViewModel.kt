package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.TrollSoundEngine
import com.example.data.GameProgressRepository
import com.example.data.PlayerProgress
import com.example.game.GameEvent
import com.example.game.LevelCatalog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface AppScreen {
    data object Home : AppScreen
    data object LevelSelect : AppScreen
    data class Playing(val levelNumber: Int) : AppScreen
    data object GrandVictory : AppScreen
}

data class GameSessionUiState(
    val screen: AppScreen = AppScreen.Home,
    val currentLevelNumber: Int = 1,
    val levelDeaths: Int = 0,
    val sessionRunDeaths: Int = 0,
    val deathGeneration: Int = 0
)

class TrollDashViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GameProgressRepository(application.applicationContext)
    val soundEngine = TrollSoundEngine()

    val progress: StateFlow<PlayerProgress> = repository.progressFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = PlayerProgress()
    )

    private val _uiState = MutableStateFlow(GameSessionUiState())
    val uiState: StateFlow<GameSessionUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            progress.collect { p ->
                soundEngine.enabled = p.soundEnabled
            }
        }
    }

    fun openHome() {
        _uiState.update { it.copy(screen = AppScreen.Home) }
    }

    fun openLevelSelect() {
        _uiState.update { it.copy(screen = AppScreen.LevelSelect) }
    }

    fun startLevel(levelNumber: Int) {
        val clamped = levelNumber.coerceIn(1, LevelCatalog.levels.size)
        _uiState.update {
            it.copy(
                screen = AppScreen.Playing(clamped),
                currentLevelNumber = clamped,
                levelDeaths = 0,
                deathGeneration = it.deathGeneration + 1
            )
        }
    }

    fun startNextLevel() {
        val current = _uiState.value.currentLevelNumber
        if (current >= LevelCatalog.levels.size) {
            _uiState.update { it.copy(screen = AppScreen.GrandVictory) }
        } else {
            startLevel(current + 1)
        }
    }

    fun onGameEvent(event: GameEvent) {
        when (event) {
            GameEvent.JUMP -> soundEngine.playJump()
            GameEvent.TRAP_TRIGGERED -> soundEngine.playTrapTrigger()
            GameEvent.TROLL_LAUGH -> soundEngine.playTrollLaugh()
            GameEvent.FAKE_CLEAR -> soundEngine.playLevelClear()
            GameEvent.DEATH -> {
                soundEngine.playDeathSplat()
                _uiState.update {
                    it.copy(
                        levelDeaths = it.levelDeaths + 1,
                        sessionRunDeaths = it.sessionRunDeaths + 1,
                        deathGeneration = it.deathGeneration + 1
                    )
                }
                viewModelScope.launch {
                    repository.recordDeath()
                }
            }
            GameEvent.LEVEL_CLEAR -> {
                soundEngine.playLevelClear()
                val levelNum = _uiState.value.currentLevelNumber
                val deaths = _uiState.value.levelDeaths
                viewModelScope.launch {
                    repository.recordLevelCleared(levelNum, deaths)
                }
            }
        }
    }

    fun onRespawnButtonDodged() {
        soundEngine.playButtonDodge()
    }

    fun toggleSound() {
        val next = !progress.value.soundEnabled
        soundEngine.enabled = next
        viewModelScope.launch {
            repository.setSoundEnabled(next)
        }
    }

    fun toggleHaptics() {
        val next = !progress.value.hapticsEnabled
        viewModelScope.launch {
            repository.setHapticsEnabled(next)
        }
    }

    fun unlockAllLevels() {
        viewModelScope.launch {
            repository.unlockAllLevels()
        }
    }

    fun resetProgress() {
        viewModelScope.launch {
            repository.resetProgress()
        }
    }
}
