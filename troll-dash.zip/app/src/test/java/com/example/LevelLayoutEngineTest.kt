package com.example

import com.example.game.GameEngine
import com.example.game.GameEvent
import com.example.game.LevelCatalog
import com.example.game.PlatformKind
import com.example.game.RotationPivot
import com.example.game.levelLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LevelLayoutEngineTest {

    @Test
    fun `all 10 levels build cleanly and include deceptive vanish and rotate platforms`() {
        assertEquals(10, LevelCatalog.levels.size)
        val allPlatforms = LevelCatalog.levels.flatMap { it.platforms }
        assertTrue(allPlatforms.any { it.kind == PlatformKind.VANISH_ON_TOUCH })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.ROTATE_ON_TOUCH })
    }

    @Test
    fun `vanishOnTouch platform appears solid then disappears shortly after touch`() {
        val events = mutableListOf<GameEvent>()
        val level = levelLayout(
            number = 1,
            title = "Vanish Test",
            subtitle = "Test",
            difficultySkulls = 1,
            worldWidth = 400f,
            spawnX = 20f,
            spawnY = 170f
        ) {
            vanishOnTouch(x = 0f, y = 200f, w = 120f, h = 24f, vanishDelaySec = 0.08f)
            exitDoor(x = 340f, y = 154f)
        }

        val engine = GameEngine(level) { events += it }
        assertTrue(engine.snapshot.platforms.first().active)
        assertFalse(engine.snapshot.platforms.first().triggered)

        // Step until player lands on platform and triggers vanish
        repeat(20) { engine.step(0.016f) }
        val platform = engine.snapshot.platforms.first()
        assertTrue("Expected platform to trigger on touch", platform.triggered)
        assertFalse("Expected platform to vanish after delay", platform.active)
        assertTrue(GameEvent.TRAP_TRIGGERED in events)
    }

    @Test
    fun `rotateOnTouch platform starts flat then rotates open and drops player`() {
        val level = levelLayout(
            number = 2,
            title = "Rotate Test",
            subtitle = "Test",
            difficultySkulls = 1,
            worldWidth = 400f,
            spawnX = 20f,
            spawnY = 170f
        ) {
            rotateOnTouch(
                x = 0f,
                y = 200f,
                w = 120f,
                h = 24f,
                targetDeg = 90f,
                speedDegPerSec = 500f,
                pivot = RotationPivot.LEFT_EDGE
            )
            exitDoor(x = 340f, y = 154f)
        }

        val engine = GameEngine(level) {}
        assertEquals(0f, engine.snapshot.platforms.first().rotationDeg, 0.01f)

        // Step simulation: player lands, triggers rotation, trapdoor swings open, player falls below y=200
        repeat(35) { engine.step(0.016f) }
        val snap = engine.snapshot
        val platform = snap.platforms.first()
        assertTrue("Expected platform to trigger on touch", platform.triggered)
        assertTrue("Expected platform to rotate past 45 deg", platform.rotationDeg >= 45f)
        assertTrue("Expected player to fall through rotated trapdoor", snap.player.y > 205f)
    }
}
